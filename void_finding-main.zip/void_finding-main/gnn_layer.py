import torch
from torch import nn
from torch_geometric.nn.models import MLP

from gnn_utils import FiLM, LayerScale, DropPath
from gnn_message import MyMessagePassing, AttentionMessagePassing

class GNNLayer(nn.Module):
    """
    One stack layer:
      - PP messages: P <- P
      - GP messages: P <- G
      - Fuse relations (FiLM by global g)
      - Residual update on P (LayerNorm, LayerScale, DropPath)
    """
    def __init__(self,
                 d_h,          # node hidden dim (P and G share feature dim)
                 d_m,          # message dim per relation
                 d_edge,       # edge attribute dim
                 d_g,          # global latent dim
                 drop_path=0.0,
                 attn=False,
                 mp_aggr='mean', # if a list, will do separate aggregations and concatenate
                 mlp_act='relu', 
                 mp_gate=False, mlp_L=2, mlp_norm=None,
                 attn_heads=4, attn_edge_bias=True, attn_edge_v=False, attn_drop=0.0,
                 eta_init=1e-1, eta_per_channel=True,
                 long_residual=False):
        super().__init__()

        P_scale = 1+bool(long_residual)
        out_div = len(mp_aggr) if isinstance(mp_aggr, list) else 1

        # Relation convs
        mp_pp_args = dict(in_src=d_h*P_scale, in_dst=d_h*P_scale, in_edge=d_edge,
                          msg_dim=d_m, out_dim=d_m//out_div, aggr=mp_aggr, mlp_act=mlp_act)
        mp_gp_args = dict(in_src=d_h, in_dst=d_h*P_scale, in_edge=d_edge,
                          msg_dim=d_m, out_dim=d_m//out_div, aggr=mp_aggr, mlp_act=mlp_act)
        if attn :
            mp_extra_args = dict(heads=attn_heads, edge_bias=attn_edge_bias, edge_v=attn_edge_v, drop=attn_drop)
            self.mp_pp = AttentionMessagePassing(**mp_pp_args, **mp_extra_args)
            self.mp_gp = AttentionMessagePassing(**mp_gp_args, **mp_extra_args)
        else :
            mp_extra_args = dict(gate=mp_gate, mlp_L=mlp_L, mlp_norm=mlp_norm)
            self.mp_pp = MyMessagePassing(**mp_pp_args, **mp_extra_args)
            self.mp_gp = MyMessagePassing(**mp_gp_args, **mp_extra_args)

        # Fusion of PP/GP channels
        self.fuse = MLP(in_channels=d_m*2, hidden_channels=d_h, out_channels=d_h, num_layers=mlp_L,
                        act=mlp_act, norm=mlp_norm, plain_last=True)  # produce an update-sized vector

        # then FiLM with the global
        self.film = FiLM(cond_dim=d_g, feat_dim=d_h) if d_g else None

        # Residual update on P
        # while it appears to make more sense to learn the log of eta, apparently this isn't done in practice
        # so let's stick with what people like to do for now
        self.layer_scale = LayerScale(dim=d_h, init_value=eta_init, per_channel=eta_per_channel)
        self.drop_path = DropPath(drop_path)
        self.norm = nn.LayerNorm(d_h)


    def forward(self,
                hP_long, hP_short, hG,
                edge_PP, edge_GP,
                g # d_g global latent
                ) :

        ei_PP, ea_PP = edge_PP
        ei_GP, ea_GP = edge_GP

        # Relation-specific aggregated messages into A
        M_PP = self.mp_pp(x_src=hP_long, x_dst=hP_long, edge_index=ei_PP, edge_attr=ea_PP)  # (N_A, d_m)
        M_GP = self.mp_gp(x_src=hG,      x_dst=hP_long, edge_index=ei_GP, edge_attr=ea_GP)  # (N_A, d_m)

        # Fuse
        M = torch.cat([M_PP, M_GP], dim=-1)          # (N_A, 2*d_m)
        M = self.fuse(M)                             # (N_A, d_h)

        # FiLM by global g
        if self.film :
            M = self.film(M, g)    # (N_A, d_h)

        # Residual update on A
        M = self.layer_scale(M)
        M = self.drop_path(M)
        hP = self.norm(hP_short + M)

        return hP
