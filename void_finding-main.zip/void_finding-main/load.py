import hashlib
import yaml

import torch

from gnn import GNN
from dataset import DataSet

def load_model (base, device=None, model: torch.nn.Module=None, do_optim=False, optim=None, ddp=False, compiled=True) :
    with open(f'{base}/cfg.yaml', 'r') as fp :
        cfg = yaml.safe_load(fp)

    if not device :
        assert model
        device = next(model.parameters()).device

    if not model :
        model = GNN(
            d_in_P=3*2*cfg['graph']['Nfourier']
                   +3*len(cfg['graph']['kfeat'])*cfg['graph']['Nfeat']
                   +cfg['data']['predict_R'],
            d_in_G=3*2*cfg['graph']['Nfourier']
                   +3*len(cfg['graph']['kfeat'])*cfg['graph']['Nfeat'],
            d_edge=4,
            d_g=1,
            d_out=3+cfg['data']['predict_R'],
            **cfg['model']
        ).to(device)

    # it's a bit awkward to deal with DDP, as per usual
    old_model_state_dict = torch.load(f'{base}/model.pt', map_location=device)
    model_state_dict = dict()
    cleanup = lambda s: k.removeprefix('module.') if compiled else k.removeprefix('module.').removeprefix('_orig_mod.')
    for k, v in old_model_state_dict.items() :
        model_state_dict[cleanup(k)] = v
    
    _model = model.module if ddp else model
    missing, unexpected = _model.load_state_dict(model_state_dict, strict=True)

    if do_optim :
        if not optim :
            optim = torch.optim.Adam(model.parameters(), lr=cfg['training']['lr'])
        optim_state_dict = torch.load(f'{base}/optimizer.pt', map_location=device)
        optim.load_state_dict(optim_state_dict)
    else :
        optim = None

    return model, optim


def load_dset (base, mode) :
    with open(f'{base}/cfg.yaml', 'r') as fp :
        cfg = yaml.safe_load(fp)

    ds_kwargs = dict(
        **cfg['data'],
        **cfg['graph'],
        interpolant=cfg['training']['interpolant']
    )
    ds_kwargs['norm_hash'] = hashlib.md5(f'{ds_kwargs}'.encode()).hexdigest()[:4]

    dset = DataSet(0, mode, **ds_kwargs)
    return dset
