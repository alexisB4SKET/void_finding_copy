import numpy as np
from matplotlib import pyplot as plt

Rmin = 60.0
deltaz = 100.0
Nseeds = 4
std = '1.0'

idx = 7649
sim = 0

colors = plt.rcParams['axes.prop_cycle'].by_key()['color']
fig, ax = plt.subplots(figsize=(5, 5))

base = '/home/lthiele/gpfs/void_finding/glx_jitter'

for seed in range(Nseeds) :

    vname = f'{base}/{sim}_{seed}_{std}/vide_{idx}/output/glx_{idx}_ss1.0/sample_glx_{idx}_ss1.0_z0.00_d00/untrimmed_centers_all_glx_{idx}_ss1.0_z0.00_d00.out'

    x = np.loadtxt(vname, usecols=(0, 1, 2))
    R = np.loadtxt(vname, usecols=(4, ))
    mask = (R>Rmin) * (x[:, 2]<deltaz)

    gname = f'{base}/{sim}_{seed}_{std}/galaxies_{idx}_1.0000.gad2'
    with open(gname, 'rb') as fp :
        fp.seek(256+2*4)
        N = np.fromfile(fp, dtype=np.int32, count=1).item() // (3*4)
        xgal = np.fromfile(fp, dtype=np.float32, count=N*3).reshape(-1, 3)

    xgal = xgal[xgal[:, 2]<deltaz][:, :2]
    ax.scatter(*xgal.T, c=colors[seed], s=0.1)

    x = x[mask][:, :2]
    R = R[mask]

    for ii in range(len(R)) :
        ax.add_patch(plt.Circle(x[ii], R[ii], fill=False, edgecolor=colors[seed], linewidth=1))

ax.set_xlim(0, 1e3)
ax.set_ylim(0, 1e3)
ax.set_xlabel('x [Mpc/h]')
ax.set_ylabel('y [Mpc/h]')

fig.savefig('jitter.pdf', bbox_inches='tight')
