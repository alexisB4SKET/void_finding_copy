
import numpy as np
from matplotlib import pyplot as plt

from glob import glob

NSTEPS = 32

for ident in ['fnlglxB_D876b-G58f0-M8b51-Tc7ea_12042051', 'fnldmA_Dc106-G58f0-M8b51-T63f1_11292333', ] :

    fig_vx, ax_vx = plt.subplots(figsize=(5, 3))
    fig_vg, ax_vg = plt.subplots(figsize=(5, 3))
    fig_vv, ax_vv = plt.subplots(figsize=(5, 3))
    fig_cr, ax_cr = plt.subplots(figsize=(5, 3))

#    for ii, b in enumerate([5.0, 15.0, ]) :
    for ii, b in enumerate([15.0, ]) :
        fnames = glob(f'/home/lthiele/gpfs/void_finding/infer_fid/{ident}/corr_{NSTEPS}steps_b{b}_rank*.npz')
        
        Rbins = np.load(fnames[0])['Rbins']
        Rcenters = 0.5 * (Rbins[1:] + Rbins[:-1])

        xi_vg_infer = np.concatenate([np.load(fname)['xi_vg_infer'] for fname in fnames], axis=0).mean(1)
        xi_vv_infer = np.concatenate([np.load(fname)['xi_vv_infer'] for fname in fnames], axis=0).mean(1)
        xi_vv_cross = np.concatenate([np.load(fname)['xi_vv_cross'] for fname in fnames], axis=0).mean(1)

        xi_vg_truth = np.concatenate([np.load(fname)['xi_vg_truth'] for fname in fnames], axis=0)
        xi_vv_truth = np.concatenate([np.load(fname)['xi_vv_truth'] for fname in fnames], axis=0)
        if not ii :
            ax_vg.plot(Rcenters, np.nanmean(xi_vg_truth, axis=0), label='reference', color='black')
            ax_vv.plot(Rcenters, np.nanmean(xi_vv_truth, axis=0), label='reference', color='black')
            #ax_vx.plot(Rcenters, np.nanmean(xi_vg_truth, axis=0), label='vg, reference', color='black', linestyle='solid')
            #ax_vx.plot(Rcenters, np.nanmean(xi_vv_truth, axis=0), label='vv, reference', color='black', linestyle='dashed')
            ax_vx.errorbar(Rcenters, np.nanmean(xi_vg_truth, axis=0), yerr=np.nanstd(xi_vg_truth, axis=0),
                           label='vg, reference', color='black', linestyle='solid')
            ax_vx.errorbar(Rcenters, np.nanmean(xi_vv_truth, axis=0), yerr=np.nanstd(xi_vv_truth, axis=0),
                           label='vv, reference', color='black', linestyle='dashed')

        ax_vg.plot(Rcenters, xi_vg_infer.mean(0), label=f'graph flow')
        ax_vv.plot(Rcenters, xi_vv_infer.mean(0), label=f'graph flow')
        ax_cr.plot(Rcenters, np.nanmean(xi_vv_cross/np.sqrt(xi_vv_infer*xi_vv_truth), 0),
                   label=f'b={b} Mpc/h')
        # ax_vx.plot(Rcenters, xi_vg_infer.mean(0), color='orange', linestyle='solid', label=f'vg, graph flow')
        # ax_vx.plot(Rcenters, xi_vv_infer.mean(0), color='orange', linestyle='dashed', label=f'vv, graph flow')
        ax_vx.errorbar(Rcenters, xi_vg_infer.mean(0), yerr=xi_vg_infer.std(0),
                       color='orange', linestyle='solid', label=f'vg, graph flow')
        ax_vx.errorbar(Rcenters, xi_vv_infer.mean(0), yerr=xi_vv_infer.std(0),
                       color='orange', linestyle='dashed', label=f'vv, graph flow')

    ax_vg.legend(loc='lower right', frameon=False)
    ax_vv.legend(loc='center left', frameon=False)
    ax_cr.legend(loc='upper left', frameon=False)

    handles, labels = ax_vx.get_legend_handles_labels()
    h_vv = [handles[ii] for ii in range(len(handles)) if 'vv' in labels[ii]]
    l_vv = [labels[ii] for ii in range(len(handles)) if 'vv' in labels[ii]]
    h_vg = [handles[ii] for ii in range(len(handles)) if 'vg' in labels[ii]]
    l_vg = [labels[ii] for ii in range(len(handles)) if 'vg' in labels[ii]]
    legend1 = ax_vx.legend(h_vg, l_vg, loc='upper left', frameon=False)
    ax_vx.add_artist(legend1)
    ax_vx.legend(h_vv, l_vv, loc='lower right', frameon=False)

    ax_vg.axhline(0, color='grey', linestyle='dashed')
    ax_vv.axhline(0, color='grey', linestyle='dashed')
    ax_cr.axhline(1, color='grey', linestyle='dashed')
    ax_vx.axhline(0, color='grey', linestyle='dotted')

    ax_vg.set_xlabel('$r$ [Mpc/$h$]')
    ax_vv.set_xlabel('$r$ [Mpc/$h$]')
    ax_cr.set_xlabel('$r$ [Mpc/$h$]')
    ax_vx.set_xlabel('$r$ [Mpc/$h$]')
    ax_vg.set_ylabel('void-galaxy 2PCF $\\xi_{vg}(r)$')
    ax_vv.set_ylabel('void-void 2PCF $\\xi_{vv}(r)$')
    ax_cr.set_ylabel('correlation graph flow - VIDE')
    ax_vx.set_ylabel('void-(galaxy/void) 2PCF $\\xi_{vx}(r)$')
    ax_cr.set_ylim(-1.2, 1.2)

    ax_vg.set_xlim(0, None)
    ax_vv.set_xlim(0, None)
    ax_cr.set_xlim(0, None)
    ax_vx.set_xlim(0, None)

    fig_vg.savefig(f'./figs/xivg_{ident}_{NSTEPS}steps.pdf', bbox_inches='tight')
    fig_vv.savefig(f'./figs/xivv_{ident}_{NSTEPS}steps.pdf', bbox_inches='tight')
    fig_cr.savefig(f'./figs/xicr_{ident}_{NSTEPS}steps.pdf', bbox_inches='tight')
    fig_vx.savefig(f'./figs/xivx_{ident}_{NSTEPS}steps.pdf', bbox_inches='tight')
