import torch
from torch import nn
from torch_geometric.nn.models import MLP

from gnn_layer import GNNLayer


# TODO need to decide if we want to update global information
# The intuition would be that it would enable us to learn things about cosmology/HOD
# So this could improve the local performance based on global knowledge
# --> For initial development, don't update global.
#     It will be interesting to add "cheated" cosmo/HOD information to global
#     And if there is a lot of performance gain, we could try to achieve the same cleanly
#        with global learned features.

class GNN(nn.Module):
    """
    Stack of L per-layer blocks operating on hetero graph:
      - P updated each layer; G kept fixed
      - PP and GP relations required in data
    Expected HeteroData fields:
      data['P'].x, data['G'].x
      data['P','PP','P'].edge_index, edge_attr
      data['G','GP','P'].edge_index, edge_attr
      optional: data['P'].batch
    """
    def __init__(self,
                 d_in_P,   # initial P features (e.g., coords)
                 d_in_G,   # initial G features
                 d_edge=4, # [dx,dy,dz,dist]
                 d_g=64, # global dimension
                 d_out=3, # output per node -- we want velocity, right??
                 d_h=128, # hidden dimension (everywhere)
                 d_m=128, # message size
                 L=4, # depth of the entire GNN
                 drop_path=0.1, # path dropping probability scale (can set to zero safely)
                 mp_attn=False,
                 mp_aggr='mean', # NOTE can be list, in which case we cycle
                 mlp_act='relu', 
                 mp_attn_heads=4, mp_attn_edge_bias=True, mp_attn_edge_v=False, mp_attn_drop=0.0,
                 mp_gate=False, mlp_L=2, mlp_norm=None,
                 eta_init=1e-1, eta_per_channel=True,
                 long_residual=False):

        super().__init__()

        # this is just for convenience basically, so we have a fixed dimensionality
        self.embedP = nn.Linear(d_in_P, d_h)
        self.embedG = nn.Linear(d_in_G, d_h)
        # Optional: positional/edge encodings could be added here
        # according to GPT, due to low dimension of edges and continuity, no embedding needed

        dps = [drop_path * ii / max(1, L-1) for ii in range(L)]  # linear decay

        self.layers = nn.ModuleList([
            GNNLayer(d_h=d_h, d_m=d_m, d_edge=d_edge, d_g=d_g, drop_path=dps[ii],
                     mp_aggr=mp_aggr[ii%len(mp_aggr)] if isinstance(mp_aggr, list) else mp_aggr,
                     attn=mp_attn[ii%len(mp_attn)] if isinstance(mp_attn, list) else mp_attn,
                     mlp_act=mlp_act, 
                     mp_gate=mp_gate, mlp_L=mlp_L, mlp_norm=mlp_norm,
                     attn_heads=mp_attn_heads, attn_edge_bias=mp_attn_edge_bias,
                     attn_edge_v=mp_attn_edge_v, attn_drop=mp_attn_drop,
                     eta_init=eta_init, eta_per_channel=eta_per_channel,
                     long_residual=bool(long_residual and ii))
            for ii in range(L)
        ])

        self.headP = MLP(in_channels=d_h*(1+long_residual), hidden_channels=d_h, out_channels=d_out, num_layers=mlp_L,
                         act=mlp_act, norm=mlp_norm, plain_last=True)

        self.long_residual = long_residual

    # FIXME following code doesn't seem necesssary
    # According to GPT, people actually use this weird initialization for modern architectures
    # Let's see if we have problems with the standard initialization, I don't think it'll be bad

    #     self._reset()
    #
    # def _reset(self):
    #     for m in self.modules():
    #         if isinstance(m, nn.Linear):
    #             nn.init.trunc_normal_(m.weight, std=0.02)
    #             if m.bias is not None:
    #                 nn.init.zeros_(m.bias)

    def forward(self, data):
        # Extract hetero pieces
        xP = data['P'].node_attr
        xG = data['G'].node_attr
        ei_PP = data['P', 'PP', 'P'].edge_index
        ea_PP = data['P', 'PP', 'P'].edge_attr
        ei_GP = data['G', 'GP', 'P'].edge_index
        ea_GP = data['G', 'GP', 'P'].edge_attr

        # global features
        g = data['U'].g

        # Embeddings
        hP_short = self.embedP(xP)
        hG = self.embedG(xG)

        # NOTE
        # We take hP_short as the "running" version of the particles,
        # while hP_long is hP_short concatenated with the original [embedded] feature vector
        # The idea is that by concatenating, we introduce the skip connections

        if self.long_residual :
            hP0 = torch.clone(hP_short)

        # Layers
        for ii, l in enumerate(self.layers) :
            hP_short = l(
                hP_long if ii else hP_short, hP_short, hG,
                (ei_PP, ea_PP),
                (ei_GP, ea_GP),
                g
            )
            if self.long_residual :
                hP_long = torch.cat([hP_short, hP0, ], dim=-1)
            else :
                hP_long = hP_short

        # Per-P latent output
        return self.headP(hP_long)  # (N_P, d_out)
