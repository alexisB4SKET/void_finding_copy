import numpy as np

import MySQLdb

rmin_g = [0, 20, 40, ]
rmin_p = [0, 10, 20, ]

db = MySQLdb.connect(
    user='myusr',
    passwd='mypwd',
    host='idark',
    port=3310,
    db='void_finding'
)

cursor = db.cursor()

# there is a shitload of data, let's only select something around a fiducial cosmology
# The +-0.05 filter in Omega_m and sigma_8 gives ~1000 points (at the moment)
cursor.execute('SELECT idx, sim FROM hod WHERE xi_state=\'success\' AND sim IN (SELECT idx FROM bsq_cosmo WHERE Om>0.25 AND Om<0.35 AND s8>0.75 AND s8<0.85)')

xi = {f'xi_gvoids_R{rmin_g_}_pvoids_R{rmin_p_}': [] for rmin_g_ in rmin_g for rmin_p_ in rmin_p}

for ii, row in enumerate(cursor.fetchall()) :
    idx = row[0]
    simidx = row[1]
    base = f'/home/lthiele/gpfs/void_finding/glx/{simidx}'
    for rmin_g_ in rmin_g :
        for rmin_p_ in rmin_p :
           fname = f'{base}/xi_gvoids_R{rmin_g_}_pvoids_R{rmin_p_}_{idx}.npy'
           xi[f'xi_gvoids_R{rmin_g_}_pvoids_R{rmin_p_}'].append(np.load(fname))

    if not (ii+1) % 100 :
        print(f'Done with {ii+1}')

cursor.close()
db.close()

for k, v in xi.items() :
    xi[k] = np.array(v)

sedges = np.linspace(0.0, 40.0, 65)
s = 0.5 * (sedges[1:] + sedges[:-1])

np.savez('void_corr.npz', s=s, **xi)
