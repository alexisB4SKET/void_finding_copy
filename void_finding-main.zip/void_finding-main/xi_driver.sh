#!/usr/bin/env bash
#set -xeo pipefail
source ~/.bashrc

starttime=$(date +%s)

DB_HOST='idark'
DB_PORT='3310'
DB_USER='myusr'
DB_PASS='mypwd'
DB_NAME='void_finding'

MYSQL_OPTS="-h${DB_HOST} -P${DB_PORT} -u${DB_USER} -p${DB_PASS} --batch --silent --skip-column-names ${DB_NAME}"

micromamba activate mysql

# get the next index
SQL=$(cat <<SQL
START TRANSACTION;

-- 1. Combine selection and row-level locking into a single query.
--    The tie-breaker logic is now: ORDER BY usage ASC, MIN(idx) ASC.
SELECT
    s.idx,
    s.sim
INTO
    @chosen_idx,
    @chosen_sim
FROM
    hod s
WHERE
    s.state = 'success' AND s.vide_state='success' AND s.xi_state = 'none'
    -- Ensure we only pick a row for the *least-used* available sim, 
    -- and prioritize the one with the smallest overall idx (first occurrence).
    AND s.sim = (
        SELECT v.sim
        FROM (
            -- All currently available sims, getting their minimum idx for tie-breaking
            SELECT sim, MIN(idx) AS min_idx
            FROM hod
            WHERE state='success' AND vide_state='success' AND xi_state='none'
            GROUP BY sim -- Group to get the min_idx for each sim
        ) AS v
        LEFT JOIN (
            -- Usage count for each sim
            SELECT sim, COUNT(*) AS used FROM hod WHERE xi_state!='none' GROUP BY sim
        ) AS u USING (sim)
        -- Primary sort: least prior usage (0, 1, 2...)
        -- Secondary sort: lowest overall idx (to prioritize older/first-seen sims)
        ORDER BY COALESCE(u.used, 0) ASC, v.min_idx ASC
        LIMIT 1
    )
ORDER BY
    s.idx ASC -- Pick the row with the lowest index among the chosen sim's available rows
LIMIT 1
FOR UPDATE;

-- 2. Handle the case where no available SIM was found.
-- 3. Mark the locked row as running.
UPDATE hod
SET xi_state = 'running'
WHERE idx = @chosen_idx;

COMMIT; -- Commit the transaction, releasing the row lock and making the UPDATE permanent.

-- 4. Result
SELECT @chosen_idx AS idx, @chosen_sim AS sim;
SQL
)

read this_idx this_sim <<< "$(mysql ${MYSQL_OPTS} -e "${SQL}")"

# deal with the case when there is no work left
if [ -z $this_idx ]; then
  exit 1
fi

# run corrfunc
micromamba activate glx
python void_corr.py "$this_idx" "$this_sim"

if [[ $? -ne 0 ]]; then
  state='failure'
else
  state='success'
fi

micromamba activate mysql

mysql ${MYSQL_OPTS} -e "UPDATE hod SET xi_state='${state}' WHERE idx=${this_idx};"

micromamba deactivate
