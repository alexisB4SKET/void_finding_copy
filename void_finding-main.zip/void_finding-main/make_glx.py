import os
import sys
from sys import argv

import numpy as np
import scipy

sys.path.append('/home/lthiele/nuvoid_production/galaxies_src')
import pyglx

SEED = int(argv[1])
SIMIDX = int(argv[2])

rng = np.random.default_rng(SEED)

# TODO need to decide!!
# BOSS CMASS 3.5e5, but we don't have halos small enough (min[logM] ~ 13.1)
# 1e5 seems like a reasonable choice
TARGET_NTOT = 1e5

database = f'/home/lthiele/cd3globus/Quijote_BSQ/fof/{SIMIDX}'
wrkdir = f'/home/lthiele/gpfs/void_finding/glx/{SIMIDX}'
os.makedirs(wrkdir, exist_ok=True)

hod_priors = {
    'sigma_logM': (0.1, 0.8),
    'delta_log_M0': (0.0, 1.0), # M0/Mmin
    'delta_log_M1': (0.0, 3.0), # M1/M0
    'alpha': (0.2, 1.5),
    'transf_eta_cen': (5.0, 10.0),
    'transf_eta_sat': (-1.0, 1.0),
}

hod_draw = {k: rng.uniform(*v) for k, v in hod_priors.items()}

# figure out logMmin required to match target density
with open(f'{database}/groups_010/group_tab_010.0', 'rb') as fp :
    header = np.fromfile(fp, dtype=np.int32, count=6)
    Ng = header[0]
    totNg = header[1]
    assert Ng == totNg
    Nf = header[5]
    assert Nf == 1
    fp.seek(Ng*4, 1) # skip GroupLen
    fp.seek(Ng*4, 1) # skip GroupOffset
    Mh = np.fromfile(fp, dtype=np.float32, count=Ng) * 1e10

def Ntot (logMmin) :
    logM0 = logMmin + hod_draw['delta_log_M0']
    logM1 = logM0 + hod_draw['delta_log_M1']
    Navg = 0.5*(1+scipy.special.erf((np.log10(Mh)-logMmin)/hod_draw['sigma_logM']))\
           *(1+((np.log10(Mh)>logM0)*(Mh-10**logM0)/10**logM1)**hod_draw['alpha'])
    return Navg.sum()

logMmin = scipy.optimize.brentq(lambda x: Ntot(x)-TARGET_NTOT, 10, 15)

hod_params = {
    'hod_log_Mmin': logMmin,
    'hod_sigma_logM': hod_draw['sigma_logM'],
    'hod_log_M0': logMmin+hod_draw['delta_log_M0'],
    'hod_log_M1': logMmin+hod_draw['delta_log_M0']+hod_draw['delta_log_M1'],
    'hod_alpha': hod_draw['alpha'],
    'hod_transf_eta_cen': hod_draw['transf_eta_cen'],
    'hod_transf_eta_sat': hod_draw['transf_eta_sat'],
}

with open(f'{wrkdir}/hod_{SEED}.info', 'w') as fp :
    fp.write(f'hod_draw={hod_draw}\n')
    fp.write(f'hod_params={hod_params}\n')

pyglx.get_galaxies(
    f'{database}', [1.0, ], f'{wrkdir}/galaxies_{SEED}',
    ftype=pyglx.FileType.gad2,
    cat=pyglx.CatalogType.oldfof,
    seed=SEED,
    **hod_params
)

# result = pyglx.get_power(
#     [f'{database}', ], 0.0,
#     rsd=pyglx.RSD.x,
#     cat=pyglx.CatalogType.oldfof,
#     seed=137, # TODO
#     **hod_params
# )
#
# np.savez(f'{wrkdir}/test_pk.npz', k=result.k, pk=result.Pk)
