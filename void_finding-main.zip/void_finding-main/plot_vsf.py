from sys import argv
import numpy as np
from matplotlib import pyplot as plt

from glob import glob

NSTEPS = 32

for ident in ['fnlglxB_D876b-G58f0-M8b51-Tc7ea_12042051', 'fnldmA_Dc106-G58f0-M8b51-T63f1_11292333', ] :

    fig_vsf, ax_vsf = plt.subplots(figsize=(5, 3))
    fig_cnt, ax_cnt = plt.subplots(figsize=(5, 2))

#    for ii, b in enumerate([5.0, 15.0, ]) :
    for ii, b in enumerate([15.0, ]) :
        fnames = glob(f'/home/lthiele/gpfs/void_finding/infer_fid/{ident}/vsf_{NSTEPS}steps_b{b}_rank*.npz')

        Rbins = np.load(fnames[0])['Rbins']
        Rcenters = 0.5 * (Rbins[1:]+Rbins[:-1])

        hinfer = np.concatenate([np.load(fname)['hinfer'] for fname in fnames], axis=0)
        htruth = np.concatenate([np.load(fname)['htruth'] for fname in fnames], axis=0)
        hcnt = np.concatenate([np.load(fname)['hcnt'] for fname in fnames], axis=0)

        if not ii :
            htruth = np.concatenate([np.load(fname)['htruth'] for fname in fnames], axis=0)
            ax_vsf.errorbar(Rcenters, np.nanmean(htruth, axis=0), yerr=np.nanstd(htruth, axis=0),
                            label='reference', color='black')
        
        delta = (+1 if ii else -1) * 0.1 * (Rbins[1]-Rbins[0])
        
        l,_,_ = ax_vsf.errorbar(Rcenters+delta, hinfer.mean(1).mean(0), yerr=hinfer.mean(1).std(0),
                                label=f'graph flow, mean', color='orange' if 'glx' in ident else 'green')

        # TODO is the std calculation correct? experimentally it seems to be fine
        #      this is relevant for cov calculation for fisher too
        ax_vsf.errorbar(Rcenters+2*delta, hinfer.mean(1).mean(0), yerr=hinfer.reshape(-1, 24).std(0),
                        label=f'graph flow, samples', color=l.get_color(), alpha=0.3)
        ax_cnt.plot(Rcenters+delta,
                    hcnt.mean(1).sum(0)/(Rcenters**3*hinfer.mean(1).sum(0))*(Rcenters**3*hinfer.mean(1).sum(0)).sum()/(1e3*hcnt.shape[0]),
                    linestyle='none', marker='o', label=f'graph flow')

    ax_vsf.legend(loc='lower left', frameon=False)
    ax_vsf.set_xlabel('void radius $R$ [Mpc/$h$]')
    ax_vsf.set_ylabel('void size function $N(R)$ [(Gpc/$h$)$^{-3}$]')
    ax_vsf.set_yscale('log')
    fig_vsf.savefig(f'./figs/vsf_{ident}_{NSTEPS}steps.pdf', bbox_inches='tight')

    ax_cnt.set_xlabel('void radius $R$ [Mpc/$h$]')
    ax_cnt.set_ylabel('#test parts./expected')
    ax_cnt.axhline(1, color='grey', linestyle='dashed')
    fig_cnt.savefig(f'./figs/count_consistency_{ident}_{NSTEPS}steps.pdf', bbox_inches='tight')
