#!/usr/bin/env bash
#set -xeo pipefail
source ~/.bashrc

DB_HOST='idark'
DB_PORT='3310'
DB_USER='myusr'
DB_PASS='mypwd'
DB_NAME='void_finding'
TABLE='vide_state_dm'

MYSQL_OPTS="-h${DB_HOST} -P${DB_PORT} -u${DB_USER} -p${DB_PASS} --batch --silent --skip-column-names ${DB_NAME}"

micromamba activate mysql

indices=$(mysql ${MYSQL_OPTS} -e "SELECT idx FROM vide_state_dm WHERE state='running'")

base='/home/lthiele/gpfs/void_finding/vide_dm'
markerf='output/dm_ss0.1/sample_dm_ss0.1_z0.00_d00/trimmed_nodencut_sky_positions_all_dm_ss0.1_z0.00_d00.out'

for idx in $indices; do
  if [ -f "${base}/${idx}/${markerf}" ]; then
    mysql ${MYSQL_OPTS} -e "UPDATE vide_state_dm SET state='success' WHERE idx=${idx}"
  else
    mysql ${MYSQL_OPTS} -e "UPDATE vide_state_dm SET state='failure' WHERE idx=${idx}"
  fi
done
