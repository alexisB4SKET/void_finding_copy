import numpy as np

import MySQLdb

db = MySQLdb.connect(
    user='myusr',
    passwd='mypwd',
    host='idark',
    port=3310,
    db='void_finding'
)
cursor = db.cursor()


c = np.loadtxt('/home/lthiele/cd3globus/Quijote_BSQ/BSQ_params.txt')

for ii, c_ in enumerate(c) :
    cval = ','.join(map(str,c_))
    cursor.execute(f'INSERT INTO bsq_cosmo (idx,Om,Ob,h,ns,s8) VALUES ({ii},{cval});')

db.commit()
cursor.close()
db.close()
