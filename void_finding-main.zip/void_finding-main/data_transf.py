import torch
from torch_geometric.data import HeteroData
from torch_cluster import knn
from torch_geometric.utils import scatter

def _build_graph (k, x1, x2=None) :
    if x2 is not None :
        self = False
    else :
        x2 = x1
        self = True

    row, col = knn(x=x2, y=x1, k=k+self) # plus 1 for self-loop

    if self :
        self_mask = row==col
        row = row[~self_mask]
        col = col[~self_mask]

    ei = torch.stack([col, row], dim=0) # 2, E
    dx = x2[col] - x1[row] # E, 3
    s = dx.norm(dim=1, keepdim=True) # E, 1

    ea = torch.cat([dx, s], dim=1)
    return ei, ea

def _fourier (x, N) :
    nu = 2**torch.linspace(0, N, N, device=x.device) * torch.pi / 1e3 # BoxSize is hardcoded to 1e3
    out = torch.cat(
        [
            f(x[:, :, None] * nu[None, None, :]).view(-1, 3*N)
            for f in [torch.sin, torch.cos, ]
        ],
        dim=-1
    )
    # these features are somewhat poorly distributed, so let's Gaussianize them
    out = torch.erfinv(2*torch.arcsin(out)/torch.pi)
    
    # need to deal with numerical issues here, extremely rare [O(10) per volume]
    out[torch.isposinf(out)] = +3
    out[torch.isneginf(out)] = -3

    return out


def _handfeatures (k, x1, x2=None, N=4) :
    """
    Some handcrafted features.
    They come in groups of 3 for convenience, controlled by N
    """
    assert 0<N<=4
    out = torch.empty((len(x1), 0), device=x1.device)

    if x2 is not None :
        self = False
    else :
        x2 = x1
        self = True

    row, col = knn(x=x2, y=x1, k=k+1)
    
    if self :
        self_mask = row==col
        row = row[~self_mask]
        col = col[~self_mask]

    dx = x2[col] - x1[row] # E, 3
    s = dx.norm(dim=1, keepdim=True) # E, 1
    u = dx / s # unit vectors, E, 3
    
    # get local density statistics, no directionality
    rmax = scatter(s, row, reduce='max', dim_size=len(x1))
    rmean = scatter(s, row, reduce='mean', dim_size=len(x1))
    rstd = scatter(s**2, row, reduce='mean', dim_size=len(x1))
    rstd = (rstd - rmean.square()).sqrt()

    out = torch.cat([out, rmax, rmean, rstd, ], dim=-1)
    if N == 1 :
        return out

    # the local quadratic structure
    dx2 = dx[:, :, None] * dx[:, None, :]
    S = torch.zeros(len(x1), 3, 3, device=x1.device)
    S.index_add_(0, row, dx2)
    S = 0.5 * (S + S.transpose(1, 2))

    # NOTE the eigh fails on GPU with the default cusolver backend
    # The entire thing is faster on CPU anyways, but in case we ever need to do it on GPU,
    #        torch.backends.cuda.preferred_linalg_library("magma")
    # would enable it to run
    evals, evecs = torch.linalg.eigh(S) # ascending eigenvalues by convention
    l1 = evals[:, 2:3] # largest, [N, 1]
    l2 = evals[:, 1:2]
    l3 = evals[:, 0:1]

    # summaries of the eigenvalue structure
    linearity = (l1 - l2) / l1
    planarity = (l2 - l3) / l1
    scattering = l3 / l1

    out = torch.cat([out, linearity, planarity, scattering, ], dim=-1)
    if N == 2 :
        return out
    
    v1 = evecs[:, :, 2] # dominant eigenvector
    out = torch.cat([out, v1, ], dim=-1)
    if N == 3 :
        return out

    # some measure of the gradient
    grad = torch.zeros(len(x1), 3, device=x1.device)
    grad.index_add_(0, row, u)
    out = torch.cat([out, grad, ], dim=-1)
    if N == 4 :
        return out

    raise RuntimeError('Cant reach here!')


@torch.no_grad()
def data_transf (xP, xG, k_PP, k_GP, Nfourier, kfeat, Nfeat, need_G_feat=True) :
    ei_PP, ea_PP = _build_graph(k_PP, xP)
    ei_GP, ea_GP = _build_graph(k_GP, xP, xG)

    feat_P = torch.cat([_handfeatures(k_, xP, xG, N=Nfeat) for k_ in kfeat], dim=-1)
    if need_G_feat :
        feat_G = torch.cat([_handfeatures(k_, xG, N=Nfeat) for k_ in kfeat], dim=-1)

    data = HeteroData()
    data['P'].node_attr = torch.cat([_fourier(xP, Nfourier), feat_P, ], dim=-1)
    if need_G_feat :
        data['G'].node_attr = torch.cat([_fourier(xG, Nfourier), feat_G, ], dim=-1)
    data['P', 'PP', 'P'].edge_index = ei_PP
    data['P', 'PP', 'P'].edge_attr = ea_PP
    data['G', 'GP', 'P'].edge_index = ei_GP
    data['G', 'GP', 'P'].edge_attr = ea_GP

    return data
