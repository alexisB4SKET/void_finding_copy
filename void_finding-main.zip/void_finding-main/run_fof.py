from sys import argv
import os.path
import MySQLdb

import numpy as np

from fof import FoF

ident = argv[1]
version = argv[2] # 'fid' or 'bsq'
rank = int(argv[3])
world_size = int(argv[4])

NSTEPS = 32
NINIT = 8
LINK_LENGTH = 5.0

db = MySQLdb.connect(user='myusr', passwd='mypwd', host='idark', port=3310, db='void_finding')
with db.cursor() as cur :
    cur.execute(f'SELECT sim, idx FROM hod{"_fid" if version=="fid" else ""} WHERE `infer_{ident}`=\'success\';')
    ids = [row for row in cur.fetchall()]
db.close()

ids = ids[rank::world_size]

base = f'/home/lthiele/gpfs/void_finding/infer_{version}/{ident}'

for ii, (sim, idx) in enumerate(ids) :

    with np.load(f'{base}/{sim}_{idx}_{NSTEPS}steps.npz') as fp :
        xall=fp['x']
        Rall=fp['R']

    for jj in range(NINIT) :

        outf = f'{base}/fof_{sim}_{idx}_{NSTEPS}steps_b{LINK_LENGTH}_init{jj}.npz'
        if os.path.isfile(outf) :
            continue

        x = xall[jj]
        R = Rall[jj]
        
        group_ids = FoF(x, LINK_LENGTH)

        unique_ids = np.unique(group_ids)
        cnt = np.array([np.count_nonzero(group_ids==kk) for kk in unique_ids])
        xavg = np.array([np.mean(x[group_ids==kk], axis=0) for kk in unique_ids])
        xstd = np.array([np.std(x[group_ids==kk], axis=0) for kk in unique_ids])
        Ravg = np.array([np.mean(R[group_ids==kk]) for kk in unique_ids])
        Rstd = np.array([np.std(R[group_ids==kk]) for kk in unique_ids])

        np.savez(outf, cnt=cnt, x=xavg, xstd=xstd, R=Ravg, Rstd=Rstd)

    print(f'Done {ii+1} / {len(ids)}')
