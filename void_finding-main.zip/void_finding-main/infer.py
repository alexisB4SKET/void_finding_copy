from sys import argv
import MySQLdb

import numpy as np
import torch

from load import load_model, load_dset

def _infer (model, dset, idx, Nsteps, Ninit) :
    device = next(model.parameters()).device

    # since the galaxies don't change during iteration, we only compute them once and store them
    # NOTE that this can be done even outside the initialization loop
    yG = None

    # we initialize particles identically all the time to remove this variance
    rng = torch.Generator().manual_seed(137)

    xP_all = []
    RP_all = []

    # our choice of times: the paths tend to be more curved at the beginning,
    # so we devote more precision there,
    # and then we add a bit of precision at the end so we get good convergence of paths
    t_ = np.linspace(0,1,num=Nsteps+1)
    tarr = (1-0.1)*(3*t_**2-2*t_**3)**1.5+0.1*t_
    harr = tarr[1:]-tarr[:-1]
    tarr = tarr[:-1]

    for jj in range(Ninit) :

        xG, xP, RP = dset.get_particles(idx, rng, for_testing=True)

        model.eval()
        with torch.no_grad() :
            for ii in range(Nsteps) :

                t = tarr[ii]
                h = harr[ii]

                x = dset.assemble_output(xG, xP, None, RP, None, t, need_G_feat=yG is None).to(device)
                if yG is None :
                    yG = x['G'].node_attr.clone()
                else :
                    x['G'].node_attr = yG.clone()

                v = model(x)
                xP += 100.0 * v[:, :3].to(xP.device) * h
                RP += v[:, 3:4].to(RP.device) * h

        xP_all.append(xP.numpy(force=True))
        RP_all.append(RP.numpy(force=True).squeeze())

    return (
        np.stack(xP_all, axis=0),
        np.stack(RP_all, axis=0)
    )

def get_sim (db, ident, table) :

    extra = 'AND sim<1000 ' if table=='hod' else ''

    try:
        db.autocommit(False)

        with db.cursor() as cur:

            # atomically pick & lock a random NULL-state row
            cur.execute(f'SELECT sim, idx FROM {table} WHERE `infer_{ident}` IS NULL AND vide_state=\'success\' {extra}ORDER BY RAND() LIMIT 1 FOR UPDATE;')
            row = cur.fetchone()

            if row is None:
                db.rollback()
                return None, None

            sim, idx = row

            # update the chosen row
            cur.execute(f'UPDATE {table} SET `infer_{ident}`=\'running\' WHERE sim=%s AND idx=%s;', (sim, idx))

        db.commit()
        return sim, idx

    except Exception:
        db.rollback()
        raise

if __name__ == '__main__' :

    ident = argv[1]
    device = f'cuda:{int(argv[2])}'
    Nsteps = int(argv[3])
    Ninit = int(argv[4])
    version = argv[5] # 'bsq' or 'fid'

    table = {'bsq': 'hod', 'fid': 'hod_fid'}[version]

    base = f'/home/lthiele/gpfs/void_finding/checkpoints/{ident}'
    
    model, _ = load_model(base, device=device, ddp=False, compiled=False)
    dset = load_dset(base, f'test{"fid" if version=="fid" else ""}')

    db = MySQLdb.connect(user='myusr', passwd='mypwd', host='idark', port=3310, db='void_finding')
    while True :
        sim, idx = get_sim(db, ident, table)
        if sim is None : # out of data
            break
        xP, RP = _infer(model, dset, (sim, idx), Nsteps, Ninit)
        RP = dset.Rmin * np.exp(RP)
        np.savez(f'/home/lthiele/gpfs/void_finding/infer_{version}/{ident}/{sim}_{idx}_{Nsteps}steps.npz', x=xP, R=RP)
        with db.cursor() as cur :
            cur.execute(f'UPDATE {table} SET `infer_{ident}`=\'success\' WHERE sim=%s AND idx=%s;', (sim, idx))
        db.commit()

    db.close()
