from sys import stderr
import hashlib
import time

import numpy as np
import MySQLdb
from scipy.optimize import linear_sum_assignment
import sympy as sp

import torch
from torch_geometric.data import Dataset as pyg_Dataset

from data_transf import data_transf

# TODO think about periodicity / edge buffer -- is it required? beneficial?


def _get_indices (void_type, mode) :
    """
    Calls into the database to figure out what data we have available
    """

    db = MySQLdb.connect(user='myusr', passwd='mypwd', host='idark', port=3310, db='void_finding')

    if mode == 'testfid' : # special case
        q = 'SELECT sim, idx FROM hod_fid WHERE vide_state=\'success\' ORDER BY idx ASC;'
        with db.cursor() as cursor :
            cursor.execute(q)
            out = torch.tensor([row for row in cursor.fetchall()])
        db.close()
        return out


    with db.cursor() as cursor :

        # we adopt the following convention: the first dimension is *always* the simulation
        # other dimensions can contain further information
        # We discard some extremely rare failure cases for simplicity

        # since each rank runs this independently, we need to be careful to make it deterministic
        q = 'SELECT sim, idx FROM hod WHERE vide_state=\'success\' AND sim IN (SELECT sim FROM vide_state_dm WHERE state=\'success\')  ORDER BY idx ASC;'

        cursor.execute(q)
        out = torch.tensor([row for row in cursor.fetchall()])

    db.close()

    # there is some remaining deterministic behaviour due to how we run VIDE, so let's fix that
    rng = torch.Generator().manual_seed(137)
    out = out[torch.randperm(len(out), generator=rng)]

    test_mask = out[:, 0]<1000 # very simple
    if mode == 'test' :
        return out[test_mask]
    else :
        out = out[~test_mask]

    valid_mask = out[:, 0]<2000 # keep it simple
    if mode == 'valid' :
        return out[valid_mask]
    else :
        out = out[~valid_mask]

    # we must be in train mode
    return out


def _ints_to_seed (*args) :
    digest = hashlib.md5(','.join(map(str, args)).encode()).digest()
    return int.from_bytes(digest[:8], 'big') & 0xFFFFFFFF



def _cat_graphs (G1, G2) :
    # NOTE that ordering matters here, for computation of offsets
    # NOTE there is the efficiency trick that the G-part is identical for both
    #      and actually we don't compute it for the G2 one

    Poffset = len(G1['P'].node_attr)
    G2['P', 'PP', 'P'].edge_index += Poffset
    G2['G', 'GP', 'P'].edge_index[1] += Poffset

    G1['P', 'PP', 'P'].edge_index = torch.cat([G1['P', 'PP', 'P'].edge_index,
                                               G2['P', 'PP', 'P'].edge_index, ], dim=1)
    G1['G', 'GP', 'P'].edge_index = torch.cat([G1['G', 'GP', 'P'].edge_index,
                                               G2['G', 'GP', 'P'].edge_index, ], dim=1)
    G1['P'].node_attr = torch.cat([G1['P'].node_attr,
                                   G2['P'].node_attr, ], dim=0)
    G1['P', 'PP', 'P'].edge_attr = torch.cat([G1['P', 'PP', 'P'].edge_attr,
                                              G2['P', 'PP', 'P'].edge_attr, ], dim=0)
    G1['G', 'GP', 'P'].edge_attr = torch.cat([G1['G', 'GP', 'P'].edge_attr,
                                              G2['G', 'GP', 'P'].edge_attr, ], dim=0)
    G1['P'].node_targ = torch.cat([G1['P'].node_targ,
                                   G2['P'].node_targ, ], dim=0)

    assert torch.allclose(G1['U'].g, G2['U'].g)

    return G1 


def _fix_nan_inf (x: torch.Tensor, s) :
    if not torch.all(torch.isfinite(x)) :
        print(f'***WARNING: encountered {torch.count_nonzero(~torch.isfinite(x))} non-finite in {s}', file=stderr)
        x.nan_to_num_(nan=0.0, posinf=5.0, neginf=-5.0)


def _targ_indices (sampling_mode, NP, V, rng) :
    """
    Returns the indices of voids where we want to place target particles
    There are two modes, namely volume-weighted random or rank ordered
    """

    if sampling_mode == 'rnd' :
        return torch.multinomial(V, num_samples=NP, replacement=True, generator=rng)
    elif sampling_mode == 'rnk' :
        return torch.cat(
            [torch.argsort(V, descending=True, stable=True), ]*(NP//len(V)+1)
        )[:NP][torch.randperm(NP, generator=rng)]
    elif sampling_mode == 'minvar' :
        # the logic here is quite difficult to understand and it comes straight from ChatGPT,
        # but we have verified through experiment that it's fine
        w = V / V.sum()
        mu = NP * w # expectation value
        a = torch.floor(mu).to(torch.int) # how many particles we assign to each void
        r = mu - a.to(torch.float32)
        s = torch.cumsum(r, dim=0)
        U = torch.rand((), generator=rng)
        cur = torch.floor(s+U)
        prev = torch.cat([torch.zeros(1), torch.floor(s[:-1]+U), ])
        picked = (cur != prev).to(torch.int)
        a += picked

        # safety against numerical issues, this case is hit extremely rarely but it does get hit
        diff = a.sum()-NP
        if diff != 0 :
            print(f'***WARNING: hit diff={diff}', file=stderr, flush=True)
            fixed = 0
            for ii in range(len(a)) :
                if diff<0 or a[ii]>0 :
                    a[ii] += (-1 if diff>0 else +1)
                    fixed += 1
                if fixed == abs(diff) :
                    break

        return torch.arange(0, len(V), dtype=torch.int).repeat_interleave(a)[torch.randperm(NP, generator=rng)]
    else :
        raise NotImplementedError




class DataSet (pyg_Dataset) :

    def __init__ (self, seed, mode, void_type,
                  Rmin, # void size minimum
                  sampling_mode, # how we choose the voids where to place particles
                  jitter, # jitter in the target positions, in units of Rvoid if <0.1 else Mpc/h
                  interpolant, # a description of the interpolation: tuple (alpha_t, beta_t, [gamma_t]) in string form
                  buf_sz, # width of the boundary buffer
                  predict_R, # whether to do void radius prediction
                  NP,
                  k_PP, k_GP, Nfourier, kfeat, Nfeat,
                  norm_hash, # data gets normalized if this is passed
                  ) :
        super().__init__()

        assert void_type in ['glx', 'dm', ]
        assert mode in ['train', 'valid', 'test', 'testfid']
        assert sampling_mode in ['rnd', 'rnk', 'minvar', ]

        alpha_sp = sp.sympify(interpolant[0])
        alpha_dot_sp = sp.diff(alpha_sp, sp.Symbol('t'))
        self.alpha_t = lambda t: float(alpha_sp.subs({'t': t}).evalf())
        self.alpha_t_dot = lambda t: float(alpha_dot_sp.subs({'t': t}).evalf())

        beta_sp = sp.sympify(interpolant[1])
        beta_dot_sp = sp.diff(beta_sp, sp.Symbol('t'))
        self.beta_t = lambda t: float(beta_sp.subs({'t': t}).evalf())
        self.beta_t_dot = lambda t: float(beta_dot_sp.subs({'t': t}).evalf())

        if len(interpolant)>2 :
            gamma_sp = sp.sympify(interpolant[1])
            gamma_dot_sp = sp.diff(gamma_sp, sp.Symbol('t'))
            self.gamma_t = lambda t: float(gamma_sp.subs({'t': t}).evalf())
            self.gamma_t_dot = lambda t: float(gamma_dot_sp.subs({'t': t}).evalf())
        else :
            self.gamma_t = None
            self.gamma_t_dot = None

        if norm_hash is not None :
            self.norms = torch.load(f'/home/lthiele/void_finding/norms/norm_{norm_hash}.pt')
        else :
            self.norms = None

        if jitter < 0.1 :
            print('***WARNING: falling back to old jitter behavior!', file=stderr, flush=True)

        self.seed = seed # NOTE currently unused
        self.ids = _get_indices(void_type, mode)
        self.void_type = void_type
        self.mode = mode
        self.Rmin = Rmin
        self.sampling_mode = sampling_mode
        self.jitter = jitter
        self.NP = NP
        self.buf_sz = buf_sz
        self.predict_R = predict_R
        self.data_transf_kwargs = dict(k_PP=k_PP, k_GP=k_GP, Nfourier=Nfourier, kfeat=kfeat, Nfeat=Nfeat)



    def len (self) :
        return len(self.ids)


    def get_particles (self, idx, rng, for_testing=False, do_augments=True) :

        if for_testing :
            sim_nr, idx_nr = idx
        else :
            sim_nr, idx_nr = self.ids[idx]

        fid_str = '_fid' if self.mode=='testfid' else ''
        gbase = f'/home/lthiele/gpfs/void_finding/glx{fid_str}/{sim_nr}'
        pbase = f'/home/lthiele/gpfs/void_finding/vide_dm{fid_str}/{sim_nr}'

        gname = f'{gbase}/galaxies_{idx_nr}_1.0000.gad2'

        vbase = {'glx': f'{gbase}/vide_{idx_nr}', 'dm': pbase}[self.void_type]
        catident = {'glx': f'_{idx_nr}', 'dm': ''}[self.void_type]
        ss = {'glx': '1.0', 'dm': '0.1'}[self.void_type]
        vident1 = f'{self.void_type}{catident}_ss{ss}'
        vident2 = f'{vident1}_z0.00_d00'
        vname = f'{vbase}/output/{vident1}/sample_{vident2}/untrimmed_centers_all_{vident2}.out'

        # prepare augmentations
        if for_testing or not do_augments :
            augment = lambda x_: x_
        else :
            shift = 1e3 * torch.rand(3, generator=rng) # translation
            P = torch.eye(3)[torch.randperm(3, generator=rng)]  # permutation
            D = torch.diag(1-2*torch.randint(0, 2, (3,), generator=rng)).to(torch.float32) # flip
            R = D @ P
            augment = lambda x_: ((x_-500)@R.T+shift)%1e3

        # load galaxies
        with open(gname, 'rb') as fp :
            fp.seek(256+2*4, 0)
            Ngal = np.fromfile(fp, count=1, dtype=np.int32)[0] // (3*4)
            xG = torch.from_numpy(np.fromfile(fp, count=3*Ngal, dtype=np.float32).reshape(Ngal, 3))
        xG = augment(xG)

        # draw the random initial starting points
        # TODO at the moment, we don't take buf_sz into account (should be small correction, worry later)
        xP = 1e3 * torch.rand((self.NP, 3), generator=rng)

        # add the radii, and let's keep it more general so we could return other properties too
        RP = torch.rand((self.NP, ), generator=rng).unsqueeze(-1)

        if for_testing :
            return xG, xP, RP

        # load voids
        xV = torch.from_numpy(np.loadtxt(vname, usecols=(0, 1, 2, ), dtype=np.float32))
        xV = augment(xV)
        RV, VV = torch.from_numpy(np.loadtxt(vname, usecols=(4, 6, ), unpack=True, dtype=np.float32))

        # cut according to radius and placement (if requested)
        mask = RV>self.Rmin
        if self.buf_sz :
            mask *= torch.all(xV>self.buf_sz, dim=1) * torch.all(xV<(1e3-self.buf_sz), dim=1)

        # for our intuition
        if idx < 32 :
            print(f'In idx={idx}, have {np.count_nonzero(mask)} voids.', flush=True)

        xV = xV[mask]
        RV = RV[mask]
        VV = VV[mask]

        # compute target positions for tracers
        # NOTE that the jittering is kind of necessary in order to make the OT unique
        targ_indices = _targ_indices(self.sampling_mode, self.NP, VV, rng)
        xT = torch.normal(
            mean=xV[targ_indices],
            std=self.jitter*RV[targ_indices].unsqueeze(1) if self.jitter<0.1 else self.jitter,
            generator=rng
        )

        # solve matching of xP to xT via Hungarian algorithm and reorder
        C = torch.cdist(xT, xP, p=2) # T x P
        Tidx, Pidx = linear_sum_assignment(C.numpy(force=True))
        xT = xT[Tidx]
        xP = xP[Pidx]

        RT = torch.log(RV[targ_indices][Tidx] / self.Rmin).unsqueeze(-1)

        return xG, xP, xT, RP, RT


    def fix_nan_inf (self, x) :
        _fix_nan_inf(x['P'].node_attr, f'{self.mode}-P')
        _fix_nan_inf(x['G'].node_attr, f'{self.mode}-G')
        _fix_nan_inf(x['P', 'PP', 'P'].edge_attr, f'{self.mode}-PP')
        _fix_nan_inf(x['G', 'GP', 'P'].edge_attr, f'{self.mode}-GP')
        _fix_nan_inf(x['U'].g, f'{self.mode}-U')
        return x


    def assemble_output (self, xG, xI, vxI, RI, vRI, t, need_G_feat=True, yG=None) :
        # we pass "physical" coordinates and velocity (v)x separately from "metadata",
        # since the former is used for the graph
        
        # build the graph and do some computations
        out = data_transf(xI, xG, **self.data_transf_kwargs, need_G_feat=need_G_feat)
        
        if vxI is not None :
            out['P'].node_targ = vxI / 100.0 # this normalization is just "by eye"
            if self.predict_R :
                out['P'].node_targ = torch.cat([out['P'].node_targ, vRI, ], dim=-1)

        if self.predict_R :
            out['P'].node_attr = torch.cat([out['P'].node_attr, RI, ], dim=-1)

        # the global features
        out['U'].g = torch.tensor([t, ], dtype=torch.float32)

        if self.norms is not None :
            zscore = lambda x, n: (x - n[0])/n[1]
            out['P'].node_attr = zscore(out['P'].node_attr, self.norms['P'])
            if need_G_feat :
                out['G'].node_attr = zscore(out['G'].node_attr, self.norms['G'])
            out['P', 'PP', 'P'].edge_attr = zscore(out['P', 'PP', 'P'].edge_attr, self.norms['PP'])
            out['G', 'GP', 'P'].edge_attr = zscore(out['G', 'GP', 'P'].edge_attr, self.norms['GP'])

        return out


    def get (self, idx) :

        # we don't have perfect reproducibility, but that's ok
        rng = torch.Generator().manual_seed(_ints_to_seed(time.time_ns(), idx))

        # NOTE that the RP, RT get returned normalized to O(1), and with a singleton axis at the end
        xG, xP, xT, RP, RT = self.get_particles(idx, rng)

        # draw the time
        t = torch.rand((1, ), generator=rng).item()

        # evolve the tracer particles along their interpolation paths
        xI = self.alpha_t(t) * xP + self.beta_t(t) * xT
        RI = self.alpha_t(t) * RP + self.beta_t(t) * RT

        if self.gamma_t is not None :
            zx = torch.randn(xI.shape, generator=rng)
            xIp = xI + self.gamma_t(t) * zx
            xIm = xI - self.gamma_t(t) * zx

            # NOTE that since delta(x) is O(1e2) and delta(R) is O(1), we need to normalize them differently
            zR = torch.randn(RI.shape, generator=rng)
            RIp = RI + 1e-2 * self.gamma_t(t) * zR
            RIm = RI - 1e-2 * self.gamma_t(t) * zR

        # the velocity field we want to match
        # NOTE that we make it numerically ~O(1) [the coefficient in assemble_output is hacked for NP=1000]
        # We *need* to remember this coefficient when doing inference!!
        vxI = self.alpha_t_dot(t) * xP + self.beta_t_dot(t) * xT
        vRI = self.alpha_t_dot(t) * RP + self.beta_t_dot(t) * RT

        if self.gamma_t is not None :
            vxIp = vxI + self.gamma_t_dot(t) * zx
            vxIm = vxI - self.gamma_t_dot(t) * zx
            vRIp = vRI + 1e-2 * self.gamma_t_dot(t) * zR
            vRIm = vRI - 1e-2 * self.gamma_t_dot(t) * zR

            outp = self.assemble_output(xG, xIp, vxIp, RIp, vRIp, t)
            outm = self.assemble_output(xG, xIm, vxIm, RIm, vRIm, t, need_G_feat=False)
            
            # it turns out to be much easier to combine everything into a single graph
            return self.fix_nan_inf(_cat_graphs(outp, outm))
        else :
            out = self.assemble_output(xG, xI, vxI, RI, vRI, t)
            return self.fix_nan_inf(out)



if __name__ == '__main__' :

    N = 1000
    NP = 1000
    NV = 300

    rng = torch.Generator().manual_seed(137)
    V = torch.rand((NV, ), generator=rng)
    indices = torch.empty((N, NP, ), dtype=torch.int)

    for ii in range(N) :
        indices[ii] = _targ_indices('minvar', NP, V, rng)

    counts = torch.empty((NV, ), dtype=torch.int)
    for jj in range(NV) :
        counts[jj] = torch.count_nonzero(indices.flatten()==jj)

    print((V/V.sum())[:32])
    print((counts/counts.sum())[:32])
    print(torch.abs(torch.log(V*counts.sum()/counts/V.sum())).mean())
