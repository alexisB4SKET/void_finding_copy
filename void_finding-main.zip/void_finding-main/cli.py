import yaml
import argparse

def CLI () :
    parser = argparse.ArgumentParser()
    parser.add_argument('--config')
    parser.add_argument('--device')
    parser.add_argument('--workers', default=9)
    args = parser.parse_args()

    with open(args.config, 'r') as fp :
        cfg = yaml.safe_load(fp)

    return args, cfg

