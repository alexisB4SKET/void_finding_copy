import torch
from torch import nn

class DropPath(nn.Module):
    """Stochastic depth. Drops entire residual branch with prob p (per-sample)."""
    def __init__(self, p=0.0):
        super().__init__()
        self.p = p
    def forward(self, x) :
        if not self.training or self.p == 0.0:
            return x
        keep = 1 - self.p
        # Per-sample binary mask, broadcast to features
        mask = torch.empty((x.shape[0],) + (1,) * (x.ndim - 1), device=x.device).bernoulli_(keep)
        return x * mask / keep

class LayerScale(nn.Module):
    """Learned scalar (or per-channel) multiplier initialized small."""
    def __init__(self, dim, init_value=1e-1, per_channel=True):
        super().__init__()
        shape = (dim,) if per_channel else (1,)
        self.gamma = nn.Parameter(init_value * torch.ones(*shape))
    def forward(self, x) :
        return x * self.gamma

class FiLM(nn.Module):
    """Feature-wise Linear Modulation: gamma, beta from global g."""
    def __init__(self, cond_dim, feat_dim):
        super().__init__()
        self.affine = nn.Linear(cond_dim, 2 * feat_dim)
    def forward(self, h, g) :
        gamma, beta = self.affine(g).chunk(2, dim=-1)
        # handcode bias on gamma so it starts close to identity
        return (1+gamma).unsqueeze(0) * h + beta.unsqueeze(0)
