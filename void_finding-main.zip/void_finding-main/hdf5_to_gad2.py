from sys import argv

import h5py
import hdf5plugin
import numpy as np

FIN = argv[1]
FOUT = argv[2]

header_fields = {
    'NumPart_ThisFile': (np.int32, 6),
    'MassTable': (np.float64, 6),
    'Time': (np.float64, 1),
    'Redshift': (np.float64, 1),
    'Flag_Sfr': (np.int32, 1),
    'Flag_Feedback': (np.int32, 1),
    'NumPart_Total': (np.uint32, 6),
    'Flag_Cooling': (np.int32, 1),
    'NumFilesPerSnapshot': (np.int32, 1),
    'BoxSize': (np.float64, 1),
    'Omega0': (np.float64, 1),
    'OmegaLambda': (np.float64, 1),
    'HubbleParam': (np.float64, 1),
    'Flag_StellarAge': (np.int32, 1),
    'Flag_Metals': (np.int32, 1),
    'NumPart_Total_HighWord': (np.uint32, 6),
    'Flag_IC_Info': (np.int32, 1), # not present in Gadget1
}

with h5py.File(FIN, 'r') as fph5, open(FOUT, 'wb') as fpgad2 :

    blksz = 256
    np.array([blksz, ], dtype=np.int32).tofile(fpgad2)

    for k, fmt in header_fields.items() :
        v = fph5['Header'].attrs[k]
        if k=='BoxSize' :
            v *= 1e-3 # convert to Mpc/h
        if fmt[1] != 1 :
            v.astype(fmt[0]).tofile(fpgad2)
        else :
            np.array([v, ], dtype=fmt[0]).tofile(fpgad2)

    written = fpgad2.tell()
    pad = 256+4 - written
    assert pad >= 0
    if pad :
        np.array([0, ]*pad, dtype=np.uint8).tofile(fpgad2)
    assert fpgad2.tell() == 256+4

    np.array([blksz, ], dtype=np.int32).tofile(fpgad2)

    N = fph5['Header'].attrs['NumPart_ThisFile'][1]

    np.array([N*3*4, ], dtype=np.int32).tofile(fpgad2)
    (fph5['PartType1/Coordinates'][...] * 1e-3).astype(np.float32).tofile(fpgad2)
    np.array([N*3*4, ], dtype=np.int32).tofile(fpgad2)

    np.array([N*3*4, ], dtype=np.int32).tofile(fpgad2)
    fph5['PartType1/Velocities'][...].astype(np.float32).tofile(fpgad2)
    np.array([N*3*4, ], dtype=np.int32).tofile(fpgad2)

    np.array([N*4, ], dtype=np.int32).tofile(fpgad2)
    fph5['PartType1/ParticleIDs'][...].astype(np.int32).tofile(fpgad2)
    np.array([N*4, ], dtype=np.int32).tofile(fpgad2)
