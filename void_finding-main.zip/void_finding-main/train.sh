#!/usr/bin/env bash

#SBATCH --job-name=train_test
#SBATCH -N 1
#SBATCH --ntasks=4
#SBATCH --gpus-per-task=1
#SBATCH --gpu-bind=none
#SBATCH -t 01:00:00
#SBATCH --nodelist=igpu02

# from tutorial at https://pytorch-geometric.readthedocs.io/en/latest/tutorial/multi_node_multi_gpu_vanilla.html
export MASTER_PORT=$(expr 10000 + $(echo -n $SLURM_JOBID | tail -c 4))
export MASTER_ADDR=$(scontrol show hostnames "$SLURM_JOB_NODELIST" | head -n 1)
echo "MASTER_ADDR:MASTER_PORT="${MASTER_ADDR}:${MASTER_PORT}

source ~/.bashrc
eval "$(micromamba shell hook --shell bash)"
micromamba activate void_finding

srun python train.py --config=configs/testdist.yaml
