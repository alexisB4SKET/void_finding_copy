#!/usr/bin/env bash
#set -xeo pipefail
source ~/.bashrc

starttime=$(date +%s)

DB_HOST='idark'
DB_PORT='3310'
DB_USER='myusr'
DB_PASS='mypwd'
DB_NAME='void_finding'

MYSQL_OPTS="-h${DB_HOST} -P${DB_PORT} -u${DB_USER} -p${DB_PASS} --batch --silent --skip-column-names ${DB_NAME}"

micromamba activate mysql

# get the next index
SQL=$(cat <<SQL
START TRANSACTION;
SELECT GET_LOCK("hod_choose_and_insert",60);
SELECT sim INTO @chosen_sim
FROM (
  SELECT s.sim, COALESCE(c.cnt,0) AS cnt
  FROM (SELECT idx AS sim FROM vide_state_dm WHERE state="success") s
  LEFT JOIN (SELECT sim, COUNT(*) cnt FROM hod GROUP BY sim) c USING (sim)
  ORDER BY cnt ASC, RAND()
  LIMIT 1
) x;
SELECT 1 FROM hod WHERE sim=@chosen_sim FOR UPDATE;
SELECT idx INTO @last_idx FROM hod ORDER BY idx DESC LIMIT 1 FOR UPDATE;
SET @next_idx := IFNULL(@last_idx, -1) + 1;
INSERT INTO hod (idx, sim, state) VALUES (@next_idx, @chosen_sim, "none");
SELECT RELEASE_LOCK("hod_choose_and_insert");
COMMIT;
SELECT @next_idx, @chosen_sim;
SQL
)

read this_idx this_sim <<< $(mysql ${MYSQL_OPTS} -e "${SQL}" | tail -1)
mysql ${MYSQL_OPTS} -e "UPDATE \`hod\` SET state='running' WHERE idx=${this_idx};"

micromamba activate glx

# we use this_idx, which doesn't carry any intrinsic information, as random seed
python make_glx.py $this_idx $this_sim

if [[ $? -ne 0 ]]; then
  state='failure'
else
  state='success'
fi

micromamba activate mysql
mysql ${MYSQL_OPTS} -e "UPDATE \`hod\` SET state='${state}' WHERE idx=${this_idx};"
