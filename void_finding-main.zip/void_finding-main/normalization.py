import hashlib
import yaml

import numpy as np
from matplotlib import pyplot as plt

import torch
from torch_geometric.loader import DataLoader as pyg_Dataloader

from dataset import DataSet
from cli import CLI

# how many graphs we gather (needs to be somewhat representative)
N = 64

# this simplify verifies an existing norm file
TEST = False

if __name__ == '__main__' :

    cli_args, cfg = CLI()

    # these *completely* define the data, use for hashing
    ds_kwargs = dict(
        **cfg['data'],
        **cfg['graph'],
        interpolant=cfg['training']['interpolant']
    )

    h = hashlib.md5(f'{ds_kwargs}'.encode()).hexdigest()[:4]

    new_or_cat = lambda x, y: torch.cat([x, y], 0) if x is not None else y
    out = {
        'P': None,
        'G': None,
        'PP': None,
        'GP': None
    }

    trainset = DataSet(0, 'train', **ds_kwargs, norm_hash=h if TEST else None)
    trainloader = pyg_Dataloader(trainset, batch_size=1, num_workers=cli_args.workers,
                                 persistent_workers=False, pin_memory=True)

    for jj, x in enumerate(trainloader) :
        if jj == N :
            break
        out['P'] = new_or_cat(out['P'], x['P'].node_attr)
        out['G'] = new_or_cat(out['G'], x['G'].node_attr)
        out['PP'] = new_or_cat(out['PP'], x['P', 'PP', 'P'].edge_attr)
        out['GP'] = new_or_cat(out['GP'], x['G', 'GP', 'P'].edge_attr)

    if not TEST :
        # diagnostic
        for k, v in out.items() :
            nr = v.shape[1]
            fig, ax = plt.subplots(nrows=nr, figsize=(5, 5*nr))
            for kk in range(nr) :
                ax[kk].hist(v[:, kk], bins=64)
                ax[kk].text(0.05, 0.95, f'{kk}', transform=ax[kk].transAxes)
            fig.savefig(f'norms/histograms_{k}_{h}.pdf', bbox_inches='tight')

    # summaries for normalization
    for k in out.keys() :
        out[k] = torch.stack([out[k].mean(0), out[k].std(0), ], 0)

    if TEST :
        print(out)

    if not TEST :
        with open(f'norms/config_{h}.info', 'w') as fp :
            yaml.dump(ds_kwargs, fp, default_flow_style=False, sort_keys=False)
        torch.save(out, f'norms/norm_{h}.pt')
