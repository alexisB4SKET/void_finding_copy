#!/usr/bin/env bash
set -eo pipefail
source ~/.bashrc

source utils.sh

idx="$1"
sim="$2"

dataroot="/home/lthiele/gpfs/void_finding/glx/${sim}/"

# this is just to get the cosmology correct
simroot="/home/lthiele/cd3globus/Quijote_BSQ/fof/${sim}"

cfg='vide_cfg_glx.py'

wrkdir="/home/lthiele/gpfs/void_finding/glx/${sim}/vide_${idx}"
mkdir -p "$wrkdir"

# prepare for vide
cp "$cfg" "$wrkdir"
cd "$wrkdir"
read Om Ob h ns s8 <<< $(cat "${simroot}/Cosmo_params.dat")

utils::replace "$cfg" 'idx' "$idx"
utils::replace "$cfg"  'Om'  "$Om"
utils::replace "$cfg"   'h'   "$h"

# run vide
micromamba activate vide
vide_prepare_simulation --all --parm "$cfg"
python -m void_pipeline "./scripts/glx_${idx}_ss1.0.py"
micromamba deactivate

# clean up (remove big files and junk)
rm -r 'figs'
rm -r 'logs'
rm -r 'scripts'
rm -r '__pycache__'

ident="glx_${idx}_ss1.0_z0.00_d00"
rm "output/glx_${idx}_ss1.0/sample_${ident}/adj_${ident}.dat"
rm "output/glx_${idx}_ss1.0/sample_${ident}/vol_${ident}.dat"
rm "output/glx_${idx}_ss1.0/sample_${ident}/zobov_slice_${ident}"
rm "output/glx_${idx}_ss1.0/sample_${ident}/zobov_slice_${ident}.par"
