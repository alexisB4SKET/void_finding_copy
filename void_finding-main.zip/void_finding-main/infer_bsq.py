from sys import argv
import MySQLdb

import numpy as np
import torch

from load import load_model, load_dset

def _infer (model, dset, idx, N) :
    device = next(model.parameters()).device

    rng = torch.Generator().manual_seed(137)
    xG, xP, RP = dset.get_particles(idx, rng, for_testing=True)

    model.eval()
    with torch.no_grad() :
        for ii in range(N) :
            t = ii / N
            x = dset.assemble_output(xG, xP, None, RP, None, t).to(device)
            v = model(x)
            xP += 100.0 * v[:, :3].to(xP.device) / N
            RP += v[:, 3:4].to(RP.device) / N
            print(f'Done {ii+1} / {N}')

    return (
        xP.numpy(force=True),
        RP.numpy(force=True).squeeze(),
    )

def get_sim (db, ident) :
    try:
        db.autocommit(False)

        with db.cursor() as cur:

            # atomically pick & lock a random NULL-state row
            cur.execute(f'SELECT sim, idx FROM hod WHERE `infer_{ident}` IS NULL AND sim<1000 AND vide_state=\'success\' ORDER BY RAND() LIMIT 1 FOR UPDATE;')
            row = cur.fetchone()

            if row is None:
                db.rollback()
                return None, None

            sim, idx = row

            # update the chosen row
            cur.execute(f'UPDATE hod SET `infer_{ident}`=\'running\' WHERE sim=%s AND idx=%s;', (sim, idx))

        db.commit()
        return sim, idx

    except Exception:
        db.rollback()
        raise

if __name__ == '__main__' :

    ident = argv[1]
    device = f'cuda:{int(argv[2])}'
    Nsteps = int(argv[3])

    base = f'/home/lthiele/gpfs/void_finding/checkpoints/{ident}'
    
    model, _ = load_model(base, device=device, ddp=False, compiled=False)
    dset = load_dset(base, 'test')

    db = MySQLdb.connect(user='myusr', passwd='mypwd', host='idark', port=3310, db='void_finding')
    while True :
        sim, idx = get_sim(db, ident)
        if sim is None : # out of data
            break
        xP, RP = _infer(model, dset, (sim, idx), Nsteps)
        RP = dset.Rmin * np.exp(RP)
        np.savez(f'/home/lthiele/gpfs/void_finding/infer_bsq/{ident}/{sim}_{idx}_{Nsteps}steps.npz', x=xP, R=RP)
        with db.cursor() as cur :
            cur.execute(f'UPDATE hod SET `infer_{ident}`=\'success\' WHERE sim=%s AND idx=%s;', (sim, idx))
        db.commit()

    db.close()
