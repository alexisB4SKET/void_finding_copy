from sys import argv
import os.path
from glob import glob
import yaml

import numpy as np
from pycorr import TwoPointCorrelationFunction

ident = argv[1]
version = argv[2]
rank = int(argv[3])
world_size = int(argv[4])

NSTEPS = 32
LINK_LENGTH = 5.0
NINIT = 8

with open(f'/home/lthiele/gpfs/void_finding/checkpoints/{ident}/cfg.yaml', 'r') as fp :
    cfg = yaml.safe_load(fp)

if cfg['data']['void_type'] == 'glx' :
    Rbins = np.linspace(0.0, 130.0, num=25)
elif cfg['data']['void_type'] == 'dm' :
    Rbins = np.linspace(0.0, 40.0, num=25)
else :
    raise RuntimeError

base = f'/home/lthiele/gpfs/void_finding/infer_{version}/{ident}'
fnames = glob(f'{base}/fof_[0-9]*_[0-9]*_{NSTEPS}steps_b{LINK_LENGTH}_init[0-9]*.npz')

fnames = np.array(sorted(fnames)).reshape(-1, NINIT)[rank::world_size]

xi_vg_infer = np.empty((len(fnames), NINIT, len(Rbins)-1))
xi_vg_truth = np.empty((len(fnames), len(Rbins)-1))
xi_vv_infer = np.empty((len(fnames), NINIT, len(Rbins)-1))
xi_vv_truth = np.empty((len(fnames), len(Rbins)-1))
xi_vv_cross = np.empty((len(fnames), NINIT, len(Rbins)-1))
simarr = np.empty((len(fnames), ), dtype=int)
idxarr = np.empty((len(fnames), ), dtype=int)

for ii, fname_list in enumerate(fnames) :

    sim = int(os.path.basename(fname_list[0]).split('_')[1])
    idx = int(os.path.basename(fname_list[0]).split('_')[2])

    simarr[ii] = sim
    idxarr[ii] = idx

    kwargs = dict(
        mode='s', edges=(Rbins, ), position_type='pos',
        engine='corrfunc', boxsize=1e3, nthreads=1
    )

    gbase = f'/home/lthiele/gpfs/void_finding/glx{"_fid" if version=="fid" else ""}/{sim}'
    pbase = f'/home/lthiele/gpfs/void_finding/vide_dm_fid/{sim}'
    vbase = {'glx': f'{gbase}/vide_{idx}', 'dm': pbase}[cfg['data']['void_type']]
    catident = {'glx': f'_{idx}', 'dm': ''}[cfg['data']['void_type']]
    ss = {'glx': '1.0', 'dm': '0.1'}[cfg['data']['void_type']]
    vident1 = f'{cfg["data"]["void_type"]}{catident}_ss{ss}'
    vident2 = f'{vident1}_z0.00_d00'
    vname = f'{vbase}/output/{vident1}/sample_{vident2}/untrimmed_centers_all_{vident2}.out'
    gname = f'{gbase}/galaxies_{idx}_1.0000.gad2'

    with open(gname, 'rb') as fp :
        fp.seek(256+2*4, 0)
        Ngal = np.fromfile(fp, count=1, dtype=np.int32)[0] // (3*4)
        xG = np.fromfile(fp, count=3*Ngal, dtype=np.float32).reshape(Ngal, 3)

    if not os.path.isfile(vname) :
        xi_vg_truth[ii] = 'nan'
        xi_vv_truth[ii] = 'nan'
        xV_truth = None
    else :
        RV_truth = np.loadtxt(vname, usecols=(4, ))
        xV_truth = np.loadtxt(vname, usecols=(0, 1, 2, ), dtype=np.float32)
        mask = RV_truth>cfg['data']['Rmin']
        mask *= np.all(xV_truth>cfg['data']['buf_sz'], axis=1) * np.all(xV_truth<(1e3-cfg['data']['buf_sz']), axis=1)
        xV_truth = xV_truth[mask]

        xi_vg_truth[ii] = TwoPointCorrelationFunction(data_positions1=xV_truth, data_positions2=xG, **kwargs)()
        xi_vv_truth[ii] = TwoPointCorrelationFunction(data_positions1=xV_truth, **kwargs)()

    for jj, fname in enumerate(fname_list) :

        assert sim==int(os.path.basename(fname).split('_')[1])
        assert idx==int(os.path.basename(fname).split('_')[2])

        with np.load(fname) as fp :
            xV_infer = fp['x']

        xi_vg_infer[ii, jj] = TwoPointCorrelationFunction(data_positions1=xV_infer, data_positions2=xG, **kwargs)()
        xi_vv_infer[ii, jj] = TwoPointCorrelationFunction(data_positions1=xV_infer, **kwargs)()
        if xV_truth is None :
            xi_vv_cross[ii, jj] = 'nan'
        else :
            xi_vv_cross[ii, jj] = TwoPointCorrelationFunction(data_positions1=xV_infer, data_positions2=xV_truth, **kwargs)()

        # FIXME
        x1 = TwoPointCorrelationFunction(data_positions1=xV_infer, **kwargs)
        print(x1.__dict__)
        raise RuntimeError

    print(f'Done with {ii+1} / {len(fnames)}')


np.savez(f'{base}/corr_{NSTEPS}steps_b{LINK_LENGTH}_rank{rank}.npz',
         Rbins=Rbins,
         xi_vg_infer=xi_vg_infer,
         xi_vg_truth=xi_vg_truth,
         xi_vv_infer=xi_vv_infer,
         xi_vv_truth=xi_vv_truth,
         xi_vv_cross=xi_vv_cross,
         sim=simarr,
         idx=idxarr)
