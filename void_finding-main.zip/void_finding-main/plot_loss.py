import yaml

import numpy as np
from matplotlib import pyplot as plt

from tensorboard.backend.event_processing.event_accumulator import EventAccumulator

def PlotLoss (ax, idents, Msamples_per_day, **kwargs) :

    step_arr = np.empty(0)
    loss_arr = np.empty(0)

    jitter = None

    for ii, ident in enumerate(idents) :
        with open(f'/home/lthiele/gpfs/void_finding/checkpoints/{ident}/cfg.yaml', 'r') as fp :
            cfg = yaml.safe_load(fp)
            if jitter is not None and jitter != cfg['graph']['jitter'] :
                changed_jitter = True
            else :
                changed_jitter = False
            jitter = cfg['graph']['jitter']

        ea = EventAccumulator(f'/home/lthiele/gpfs/void_finding/train_logs/{ident}')
        ea.Reload()

        events = ea.Scalars('Loss/valid')
        _step = np.array([e.step for e in events]).astype(np.float64)
        _loss = np.array([e.value for e in events])

        sorter = np.argsort(_step)
        _step = _step[sorter]
        _loss = _loss[sorter]
        mask = np.isfinite(_loss)
        _step = _step[mask]
        _loss = _loss[mask]

        ep = np.argmin(_loss) if ii<(len(idents)-1) else len(_step)-1
        _step = _step[:ep+1]
        _loss = _loss[:ep+1]

        _step *= 1e-6 * cfg['training']['batch_size']/Msamples_per_day
        _step += step_arr[-1] if len(step_arr) else 0

        if changed_jitter :
            ax.plot([_step[0], _step[0]], [_loss[0], _loss[0]*1.2], color='grey', linestyle='dashed')
            ax.text(_step[0]*0.90, _loss[0]*1.2, ' decreased jitter', va='bottom', ha='center', transform=ax.transData, color='grey')

        step_arr = np.concatenate([step_arr, _step])
        loss_arr = np.concatenate([loss_arr, _loss])

    ax.plot(step_arr, loss_arr, **kwargs)


if __name__ == '__main__' :

    fig, ax = plt.subplots(figsize=(5, 5))

    # full prodI on 4x4 GPUs
    Msamples_per_day_full = 1e-6*106978*48/(4 * 4 * 3.993)

    dm_idents = [
        'fnldmA_D3470-Ge336-M8b51-T08b3_11241653',
        'fnldmA_D3470-Ge336-M8b51-T12b0_11271045',
        'fnldmA_Dc106-G58f0-M8b51-T7481_11281414',
        'fnldmA_Dc106-G58f0-M8b51-T63f1_11292333',
    ]

    glx_idents = [
        'prodI_D876b-G548a-M8b51-T677d_11131738',
        'prodI_D876b-G548a-M8b51-Tbb38_11171616',
        'fnlglxB_D876b-G58f0-M8b51-Tfb77_11301705',
        'fnlglxB_D876b-G58f0-M8b51-T5294_12020940',
        'fnlglxB_D876b-G58f0-M8b51-Tc7ea_12042051',
    ]

    # testing prodB, prodC (for attention) on 1x4 GPUs
    Msamples_per_day_prodC = 1e-6*49953*32/(1 * 4 * 2.341)
    Msamples_per_day_prodB = 1e-6*42124*32/(1 * 4 * 2.815)

    prodC_idents = [
        'prodC_D876b-Geb72-M2408-T783b_11110749',
    ]

    prodB_idents = [
        'prodB_D876b-Geb72-M8595-T677d_11102037',
    ]

    PlotLoss(ax, dm_idents, Msamples_per_day_full,
             label='DM voids', color='green')
    PlotLoss(ax, glx_idents, Msamples_per_day_full,
             label='galaxy voids, production run', color='orange')
    PlotLoss(ax, prodB_idents, Msamples_per_day_prodB,
             label='galaxy voids, test run, mean+max aggr.', color='blue', linestyle='dashed')
    PlotLoss(ax, prodC_idents, Msamples_per_day_prodC,
             label='galaxy voids, test run, attention', color='purple', linestyle='dotted')
#    PlotLoss(ax, attn_idents, label='galaxy voids (attention)', marker='x', markersize=0.3)
    ax.set_yscale('log')
    ax.legend(loc='lower left', frameon=False)
    ax.set_xlabel('V100-days')
    #ax2 = ax.secondary_xaxis('top', functions=(lambda x: x/Msamples_per_day, lambda xt: xt*Msamples_per_day))
    #ax2.set_xlabel('V100-days')
    ax.set_ylabel('validation loss')
    #ax.set_xlim(0, None)
    ax.set_xscale('log')
    fig.savefig('./figs/losscurves.pdf', bbox_inches='tight')
