from sys import argv

import numpy as np
from pycorr import TwoPointCorrelationFunction

idx = int(argv[1])
simidx = int(argv[2])

base = '/home/lthiele/gpfs/void_finding'

rbins = np.linspace(0.0, 40.0, 65)
BoxSize = 1e3

rmin_g = [0, 20, 40, ]
rmin_p = [0, 10, 20, ]


# the galaxies voids
gbase = f'{base}/glx/{simidx}'
gident = f'glx_{idx}_ss1.0'
gname = f'{gbase}/vide_{idx}/output/{gident}/sample_{gident}_z0.00_d00/untrimmed_centers_all_{gident}_z0.00_d00.out'
xg = np.loadtxt(gname, usecols=(0,1,2,))
rg, vg = np.loadtxt(gname, usecols=(4, 6,), unpack=True)

# the particle voids
pident = 'dm_ss0.1'
pname = f'{base}/vide_dm/0/output/{pident}/sample_{pident}_z0.00_d00/untrimmed_centers_all_{pident}_z0.00_d00.out'
xp = np.loadtxt(pname, usecols=(0,1,2,))
rp, vp = np.loadtxt(pname, usecols=(4, 6,), unpack=True)

for ii, rmin_g_ in enumerate(rmin_g) :
    for jj, rmin_p_ in enumerate(rmin_p) :
        gmask = rg>rmin_g_
        pmask = rp>rmin_p_
        xi12 = TwoPointCorrelationFunction(
            mode='s', edges=(rbins, ),
            data_positions1=xg[gmask], data_positions2=xp[pmask],
            data_weights1=vg[gmask], data_weights2=vp[pmask],
            #weight_type='pair_product',
            position_type='pos',
            engine='corrfunc',
            boxsize=BoxSize,
            nthreads=1
        )

        xi = xi12()
        np.save(f'{gbase}/xi_gvoids_R{rmin_g_}_pvoids_R{rmin_p_}_{idx}.npy', xi) 
