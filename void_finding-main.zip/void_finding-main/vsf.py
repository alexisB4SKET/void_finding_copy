from sys import argv
import os.path
import yaml
from glob import glob

import numpy as np

ident = argv[1]
version = argv[2]
rank = int(argv[3])
world_size = int(argv[4])

NSTEPS = 32
LINK_LENGTH = 15.0
NINIT = 8

with open(f'/home/lthiele/gpfs/void_finding/checkpoints/{ident}/cfg.yaml', 'r') as fp :
    cfg = yaml.safe_load(fp)

if cfg['data']['void_type'] == 'glx' :
    Rbins = np.linspace(60, 110, num=25)
elif cfg['data']['void_type'] == 'dm' :
    Rbins = np.linspace(25, 32, num=25)
else :
    raise RuntimeError

base = f'/home/lthiele/gpfs/void_finding/infer_{version}/{ident}'
fnames = glob(f'{base}/fof_[0-9]*_[0-9]*_{NSTEPS}steps_b{LINK_LENGTH}_init[0-9]*.npz')

fnames = np.array(sorted(fnames)).reshape(-1, NINIT)[rank::world_size]

hcnt = np.empty((len(fnames), NINIT, len(Rbins)-1))
hinfer = np.empty((len(fnames), NINIT, len(Rbins)-1))
htruth = np.empty((len(fnames), len(Rbins)-1))
simarr = np.empty((len(fnames), ), dtype=int)
idxarr = np.empty((len(fnames), ), dtype=int)

for ii, fname_list in enumerate(fnames) :

    sim = int(os.path.basename(fname_list[0]).split('_')[1])
    idx = int(os.path.basename(fname_list[0]).split('_')[2])

    simarr[ii] = sim
    idxarr[ii] = idx

    gbase = f'/home/lthiele/gpfs/void_finding/glx{"_fid" if version=="fid" else ""}/{sim}'
    pbase = f'/home/lthiele/gpfs/void_finding/vide_dm_fid/{sim}'
    vbase = {'glx': f'{gbase}/vide_{idx}', 'dm': pbase}[cfg['data']['void_type']]
    catident = {'glx': f'_{idx}', 'dm': ''}[cfg['data']['void_type']]
    ss = {'glx': '1.0', 'dm': '0.1'}[cfg['data']['void_type']]
    vident1 = f'{cfg["data"]["void_type"]}{catident}_ss{ss}'
    vident2 = f'{vident1}_z0.00_d00'
    vname = f'{vbase}/output/{vident1}/sample_{vident2}/untrimmed_centers_all_{vident2}.out'
    
    if not os.path.isfile(vname) : # happens in rare cases?
        htruth[ii] = 'nan'
    else :
        xV = np.loadtxt(vname, usecols=(0, 1, 2, ), dtype=np.float32)
        RV, VV = np.loadtxt(vname, usecols=(4, 6, ), unpack=True, dtype=np.float32)

        # cut according to radius and placement (if requested)
        mask = RV>cfg['data']['Rmin']
        if cfg['data']['buf_sz'] :
            mask *= np.all(xV>cfg['data']['buf_sz'], axis=1) * np.all(xV<(1e3-cfg['data']['buf_sz']), axis=1)
        RV = RV[mask]

        htruth[ii], _ = np.histogram(RV, Rbins)

    for jj, fname in enumerate(fname_list) :

        assert sim==int(os.path.basename(fname).split('_')[1])
        assert idx==int(os.path.basename(fname).split('_')[2])

        with np.load(fname) as fp :
            R = fp['R']
            cnt = fp['cnt']
        hinfer[ii, jj], _ = np.histogram(R, Rbins)
        hcnt[ii, jj], _ = np.histogram(R, Rbins, weights=cnt)


    print(f'Done with {ii+1} / {len(fnames)}')

np.savez(f'{base}/vsf_{NSTEPS}steps_b{LINK_LENGTH}_rank{rank}.npz',
         Rbins=Rbins,
         hcnt=hcnt,
         hinfer=hinfer,
         htruth=htruth,
         sim=simarr,
         idx=idxarr)
