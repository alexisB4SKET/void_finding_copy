import math

import torch
from torch import nn
import torch_geometric
from torch_geometric.nn import MessagePassing
from torch_geometric.nn.models import MLP


class AttentionMessagePassing (MessagePassing) :
    """
    Multi-head attention for a single relation (src -> dst), with optional edge bias.
    Inputs are latent node states; edge_attr can be geometry (e.g., dx,dy,dz,dist).
    """
    def __init__(self, in_src, in_dst, in_edge,
                 msg_dim, out_dim, aggr='mean',
                 heads=4, edge_bias=True, edge_v=False, drop=0.0,
                 mlp_act='relu'):
        super().__init__(aggr=aggr, node_dim=0)
        self.h = heads
        self.d_k = msg_dim // heads
        self.d_v = msg_dim // heads
        assert msg_dim % heads == 0, "msg_dim must be divisible by heads"

        self.q_lin = nn.Linear(in_dst, self.h * self.d_k, bias=False)
        self.k_lin = nn.Linear(in_src, self.h * self.d_k, bias=False)
        self.v_lin = nn.Linear(in_src, self.h * self.d_v, bias=False)

        if edge_bias:
            self.e2b = MLP(in_channels=in_edge, out_channels=self.h, hidden_channels=self.h,
                           num_layers=2, act=mlp_act, plain_last=True, norm=None)
        else :
            self.e2b = None

        if edge_v:
            self.e2v = MLP(in_channels=in_edge, out_channels=self.h*self.d_v, hidden_channels=self.h*self.d_v,
                           num_layers=2, act=mlp_act, plain_last=True, norm=None)
        else :
            self.e2v = None

        self.out_lin = nn.Linear(msg_dim, out_dim, bias=True)
        self.drop = nn.Dropout(drop)
        self.scale = 1.0 / math.sqrt(self.d_k)

    def forward(self, x_src, x_dst, edge_index, edge_attr=None):
        self._x_src, self._x_dst, self._edge_attr = x_src, x_dst, edge_attr
        return self.propagate(edge_index, size=(x_src.size(0), x_dst.size(0)))

    def message(self, index, ptr, size_i, size_j, edge_index):
        src, dst = edge_index
        Q = self.q_lin(self._x_dst[dst]).view(-1, self.h, self.d_k)       # (E,H,d_k)
        K = self.k_lin(self._x_src[src]).view(-1, self.h, self.d_k)
        V = self.v_lin(self._x_src[src]).view(-1, self.h, self.d_v)

        # logits
        logits = (Q * K).sum(dim=-1) * self.scale                           # (E,H)
        if self.e2b is not None :
            logits = logits + self.e2b(self._edge_attr)                     # (E,H)

        # normalize over dst neighborhoods
        alpha = torch_geometric.utils.softmax(logits, index=index, num_nodes=self._x_dst.size(0)) # (E,H)
        alpha = self.drop(alpha)

        # optional edge-conditioned values
        if self.e2v is not None :
            V = V + self.e2v(self._edge_attr).view(-1, self.h, self.d_v)

        m = (alpha.unsqueeze(-1) * V).reshape(-1, self.h * self.d_v)        # (E, H*d_v)
        return m

    def update(self, aggr_out):
        return self.out_lin(aggr_out)  # (N_dst, out_dim)

class MyMessagePassing (MessagePassing) :
    """
    Relation conv with learned messages and a scalar gate per-edge.
    Aggregates to the DESTINATION node set (mean aggregation by default).
    - in_src:  dim of source node features
    - in_dst:  dim of destination node features
    - in_edge: dim of edge attributes (e.g., 4 for [dx,dy,dz,dist])
    - msg_dim: dimension of per-edge messages
    - out_dim: dimension of aggregated output per destination node

    - mlp_norm: can be None, "batch_norm", "layer_norm", anything else?
    - gate: sigmoid gating, apparently useful to suppress noise from large neighborhoods
    """
    def __init__(self, in_src, in_dst, in_edge,
                 msg_dim, out_dim, aggr='mean',
                 gate=True, mlp_L=2, mlp_act='relu', mlp_norm=None) :
        super().__init__(aggr=aggr, node_dim=0)

        # if there is no gate, we end the MLP with an activation
        # (we have another linear projection after)
        # if there is a gate, the MLP output gets used in two ways, so no activation at the end
        self.phi = MLP(in_channels=in_src+in_dst+in_edge, out_channels=msg_dim,
                       hidden_channels=msg_dim, num_layers=mlp_L,
                       act=mlp_act, norm=mlp_norm, plain_last=gate)
        self.gate = nn.Linear(msg_dim, 1) if gate else None
        self.proj = nn.Linear(msg_dim, out_dim)

    def forward(self,
                x_src,        # (N_src, F_src)
                x_dst,        # (N_dst, F_dst)
                edge_index,   # (2, E) [src, dst] indices w.r.t. (x_src, x_dst)
                edge_attr=None # (E, F_edge)
                ) :
        self._x_src = x_src
        self._x_dst = x_dst
        self._edge_attr = edge_attr
        return self.propagate(edge_index, size=(x_src.size(0), x_dst.size(0)))

    def message(self, index, ptr, size_i, size_j, edge_index) :
        # edge_index: [src, dst]; PyG passes 'index' as dst indices by default for aggr over dst
        src, dst = edge_index
        h_src = self._x_src[src]
        h_dst = self._x_dst[dst]
        if self._edge_attr is not None:
            z = torch.cat([h_dst, h_src, self._edge_attr], dim=-1)
        else:
            z = torch.cat([h_dst, h_src], dim=-1)
        m = self.phi(z) # (E, msg_dim)
        if self.gate is not None :
            g = torch.sigmoid(self.gate(m)) # (E, 1)
            m = m * g
        return self.proj(m) # (E, out_dim)

    def update(self, aggr_out) :
        # aggr_out: (N_dst, out_dim)
        return aggr_out


if __name__ == '__main__' :
    m = MyMessagePassing(8, 16, 4, 128, 64, mlp_norm='layer_norm').to('cuda:0')
    for k, v in m.named_parameters() :
        print(k)
