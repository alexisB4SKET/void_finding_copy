#!/usr/bin/env bash
set -eo pipefail
source ~/.bashrc

source utils.sh

idx="$1"

dataroot="/home/lthiele/cd3globus/Quijote_BSQ/fof/${idx}"

cfg='vide_cfg_dm.py'

wrkdir="/home/lthiele/gpfs/void_finding/vide_dm/${idx}"
mkdir -p "$wrkdir"

# convert the particle file into Gadget-2 format
micromamba activate glx
python hdf5_to_gad2.py "${dataroot}/snap_010.hdf5" "${wrkdir}/snap_010.gad2"
micromamba deactivate

# prepare for vide
cp "$cfg" "$wrkdir"
cd "$wrkdir"
read Om Ob h ns s8 <<< $(cat "${dataroot}/Cosmo_params.dat")

utils::replace "$cfg" 'Om' "$Om"
utils::replace "$cfg"  'h'  "$h"

# run vide
micromamba activate vide
vide_prepare_simulation --all --parm "$cfg"
python -m void_pipeline './scripts/dm_ss0.1.py'
micromamba deactivate

# clean up (remove big files and junk)
rm 'snap_010.gad2'
rm -r 'figs'
rm -r 'logs'
rm -r 'scripts'
rm -r '__pycache__'

ident='dm_ss0.1_z0.00_d00'
rm "output/dm_ss0.1/sample_${ident}/adj_${ident}.dat"
rm "output/dm_ss0.1/sample_${ident}/vol_${ident}.dat"
rm "output/dm_ss0.1/sample_${ident}/zobov_slice_${ident}"
rm "output/dm_ss0.1/sample_${ident}/zobov_slice_${ident}.par"
