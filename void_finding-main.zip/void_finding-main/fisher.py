import numpy as np

from matplotlib import pyplot as plt
from matplotlib.patches import Ellipse

from glob import glob

# it doesn't seem to matter for cosmo constraints, which of course makes sense
HAVE_HOD = False

HAVE_CORR = True

NSTEPS = 32
LINK_LENGTH = {'glx': 15.0, 'dm': 5.0, }

# fraction of prior we use
BSQ_RESTRICT = None #0.5

param_names = ['$\\Omega_m$', '$\\Omega_b$', '$h$', '$n_s$', '$\\sigma_8$', ]
params_fid = np.array([0.3175, 0.049, 0.6711, 0.9624, 0.834, ]) # [dim]
if HAVE_HOD :
    hod_names = ['slogM', 'dlogM0', 'dlogM1', 'alpha', 'ecen', 'esat', ]
    hod_fid = np.array([0.45, 0.5, 1.5, 0.85, 7.5, 0.0, ])

    param_names.extend(hod_names)
    params_fid = np.concatenate([params_fid, hod_fid, ])


def fisher_triangle(axs, F, color, linestyle, label, nsigmas=(1,), isfresh=True, change_lims=True):
    npar = F.shape[0]
    
    # Invert Fisher to get covariance
    C = np.linalg.pinv(F)

    # Δχ² values for Gaussian confidence regions in 2D
    # 1σ -> 2.30, 2σ -> 6.17, 3σ -> 11.8
    delta_chi2_for_sigma = {
        1: 2.30,
        2: 6.17,
        3: 11.8,
    }
    # Fallback for non-integer sigmas: Δχ² ≈ (σ)^2 * 2 (rough)
    def get_delta_chi2(s):
        if s in delta_chi2_for_sigma:
            return delta_chi2_for_sigma[s]
        return 2.0 * s**2

    def add_ellipse(ax, mean, cov2, nsigma):
        """
        Add an nsigma ellipse for 2D Gaussian with mean, covariance cov2 on ax.
        mean: (2,) array
        cov2: (2,2) array
        """
        # eigen-decomposition
        vals, vecs = np.linalg.eigh(cov2)
        # sort eigenvalues descending
        order = np.argsort(vals)[::-1]
        vals = vals[order]
        vecs = vecs[:, order]

        delta_chi2 = get_delta_chi2(nsigma)
        # axis lengths (full width/height):
        width = 2.0 * np.sqrt(delta_chi2 * vals[0])
        height = 2.0 * np.sqrt(delta_chi2 * vals[1])

        # angle of major axis (in degrees)
        angle = np.degrees(np.arctan2(vecs[1, 0], vecs[0, 0]))

        e = Ellipse(
            xy=mean,
            width=width,
            height=height,
            angle=angle,
            fill=False,
            lw=2.0,
            color=color,
            linestyle=linestyle,
            label=label
        )
        ax.add_patch(e)

    for i in range(npar):
        for j in range(npar):
            ax = axs[i, j]

            if i <= j:
                # hide upper triangle and diagonal (no 1D marginals)
                ax.set_visible(False)
                continue

            # indices of the two parameters
            p1, p2 = j, i

            # 2x2 covariance submatrix for (p1, p2)
            cov2 = C[np.ix_([p1, p2], [p1, p2])]
            mean = np.array([params_fid[p1], params_fid[p2]])

            # Draw ellipses for requested sigma levels
            for ns in nsigmas:
                add_ellipse(ax, mean, cov2, ns)

            if change_lims :
                # Center the plot around the fiducial with some padding
                sigmas_x = np.sqrt(cov2[0, 0])
                sigmas_y = np.sqrt(cov2[1, 1])
                pad_x = 3 * sigmas_x
                pad_y = 3 * sigmas_y

                if isfresh :
                    ax.set_xlim(mean[0] - pad_x, mean[0] + pad_x)
                    ax.set_ylim(mean[1] - pad_y, mean[1] + pad_y)
                else :
                    ax.set_xlim(min(mean[0] - pad_x, ax.get_xlim()[0]),
                                max(mean[0] + pad_x, ax.get_xlim()[1]))
                    ax.set_ylim(min(mean[1] - pad_y, ax.get_ylim()[0]),
                                max(mean[1] + pad_y, ax.get_ylim()[1]))

            if isfresh :
                # Tick labels: only for left column and bottom row
                if j == 0:
                    ax.set_ylabel(param_names[i])
                else:
                    ax.set_yticklabels([])

                if i == npar - 1:
                    ax.set_xlabel(param_names[j])
                else:
                    ax.set_xticklabels([])




fig, ax = plt.subplots(len(param_names), len(param_names), figsize=(7, 7),
                       gridspec_kw=dict(hspace=0.05, wspace=0.05))

idents = {
    'glx': 'fnlglxB_D876b-G58f0-M8b51-Tc7ea_12042051',
    'dm': 'fnldmA_Dc106-G58f0-M8b51-T63f1_11292333',
}

F = dict()

for ident_nick, ident in idents.items() :

    h_fid = dict()
    h_bsq = dict()

    fnames = glob(f'/home/lthiele/gpfs/void_finding/infer_fid/{ident}/vsf_{NSTEPS}steps_b{LINK_LENGTH[ident_nick]}_rank*.npz')
    idx_fid = np.concatenate([np.load(fname)['idx'] for fname in fnames], 0)
    sorter = np.argsort(idx_fid)
    idx_fid = idx_fid[sorter]
    sim_fid = np.concatenate([np.load(fname)['sim'] for fname in fnames], 0)[sorter]
    h_fid['infer_mean'] = np.concatenate([np.load(fname)['hinfer'] for fname in fnames], 0)[sorter].mean(1)
    h_fid['infer_samples'] = np.concatenate([np.load(fname)['hinfer'] for fname in fnames], 0)[sorter].reshape(-1, 24)
    h_fid['VIDE'] = np.concatenate([np.load(fname)['htruth'] for fname in fnames], 0)[sorter]
    print(f'Using {len(sim_fid)} fid sims')

    fnames = glob(f'/home/lthiele/gpfs/void_finding/infer_bsq/{ident}/vsf_{NSTEPS}steps_b{LINK_LENGTH[ident_nick]}_rank*.npz')
    idx_bsq = np.concatenate([np.load(fname)['idx'] for fname in fnames], 0)
    sorter = np.argsort(idx_bsq)
    idx_bsq = idx_bsq[sorter]
    sim_bsq = np.concatenate([np.load(fname)['sim'] for fname in fnames], 0)[sorter]
    h_bsq['infer'] = np.concatenate([np.load(fname)['hinfer'] for fname in fnames], 0)[sorter].mean(1)
    h_bsq['VIDE'] = np.concatenate([np.load(fname)['htruth'] for fname in fnames], 0)[sorter]
    print(f'Using {len(sim_bsq)} bsq sims')

    if HAVE_CORR :
        fnames = glob(f'/home/lthiele/gpfs/void_finding/infer_fid/{ident}/corr_{NSTEPS}steps_b{LINK_LENGTH[ident_nick]}_rank*.npz')
        idx_fid_ = np.concatenate([np.load(fname)['idx'] for fname in fnames], 0)
        sorter = np.argsort(idx_fid_)
        idx_fid_ = idx_fid_[sorter]
        sim_fid_ = np.concatenate([np.load(fname)['sim'] for fname in fnames], 0)[sorter]
        assert np.all(idx_fid_==idx_fid)
        h_fid['infer_mean'] = np.concatenate([h_fid['infer_mean'], np.concatenate([np.load(fname)['xi_vg_infer'] for fname in fnames], 0)[sorter].mean(1)], -1)
        h_fid['infer_samples'] = np.concatenate([h_fid['infer_samples'], np.concatenate([np.load(fname)['xi_vg_infer'] for fname in fnames], 0)[sorter].reshape(-1, 24)], -1)
        h_fid['VIDE'] = np.concatenate([h_fid['VIDE'], np.concatenate([np.load(fname)['xi_vg_truth'] for fname in fnames], 0)[sorter]], -1)

        fnames = glob(f'/home/lthiele/gpfs/void_finding/infer_bsq/{ident}/corr_{NSTEPS}steps_b{LINK_LENGTH[ident_nick]}_rank*.npz')
        idx_bsq_= np.concatenate([np.load(fname)['idx'] for fname in fnames], 0)
        sorter = np.argsort(idx_bsq_)
        idx_bsq_ = idx_bsq_[sorter]
        sim_bsq_ = np.concatenate([np.load(fname)['sim'] for fname in fnames], 0)[sorter]
        assert np.all(idx_bsq_==idx_bsq)
        h_bsq['infer'] = np.concatenate([h_bsq['infer'], np.concatenate([np.load(fname)['xi_vg_infer'] for fname in fnames], 0)[sorter].mean(1)], -1)
        h_bsq['VIDE'] = np.concatenate([h_bsq['VIDE'], np.concatenate([np.load(fname)['xi_vg_truth'] for fname in fnames], 0)[sorter]], -1)

    params_bsq = np.loadtxt('/home/lthiele/gpfs/void_finding/bsq_params.dat')[sim_bsq] # [N, dim]

    # restrict to local region
    if BSQ_RESTRICT :
        bsq_ranges = [[0.1, 0.5], [0.02, 0.08], [0.5, 0.9], [0.8, 1.2], [0.6, 1.0], ]
        mask = np.full(len(params_bsq), True, dtype=bool)
        for ii, (theta_min, theta_max) in enumerate(bsq_ranges) :
            theta_min_ = 0.5*(theta_min+theta_max) - 0.5*BSQ_RESTRICT*(theta_max-theta_min)
            theta_max_ = 0.5*(theta_min+theta_max) + 0.5*BSQ_RESTRICT*(theta_max-theta_min)
            mask *= (params_bsq[:, ii]>theta_min_) * (params_bsq[:, ii]<theta_max_)
        sim_bsq = sim_bsq[mask]
        idx_bsq = idx_bsq[mask]
        params_bsq = params_bsq[mask]
        for k, v in h_bsq.items() :
            h_bsq[k] = v[mask]
    print(f'Using {len(sim_bsq)} bsq sims after restriction')

    if HAVE_HOD :
        hod_bsq = np.array([
            list(eval(open(f'/home/lthiele/gpfs/void_finding/glx/{sim}/hod_{idx}.info', 'r').readline().rstrip().split('=')[1]).values())
            for sim, idx in np.stack([sim_bsq, idx_bsq, ], axis=1)
        ])
        
        params_bsq = np.concatenate([params_bsq, hod_bsq, ], axis=-1)

    cov = {k: np.cov(h_fid[k][np.all(np.isfinite(h_fid[k]), axis=1)], rowvar=False) for k in ['infer_mean', 'infer_samples', 'VIDE']}
    deltax = {k: h_bsq[k] - np.nanmean(h_fid[{'infer': 'infer_mean', 'VIDE': 'VIDE'}[k]], 0)[None, :] for k in ['infer', 'VIDE']}
    deltat = params_bsq - params_fid[None, :]

    assert all(np.all(np.isfinite(x)) for x in cov.values())
    assert all(np.all(np.isfinite(x)) for x in deltax.values())

    # we fit the linear model delta(x) = M delta(t), where M_ab = d(x_a) / d(theta_b)
    M = {k: np.linalg.lstsq(deltat, deltax[k])[0].T for k in ['infer', 'VIDE']}

    assert all(np.all(np.isfinite(x)) for x in M.values())

    # the fisher matrix is dx/dt . C^-1 . dx/dt
    for k in ['infer_mean', 'infer_samples', 'VIDE', ] :
        this_F = M[k.split('_')[0]].T @ np.linalg.inv(cov[k]) @ M[k.split('_')[0]]
        F[f'{ident_nick}_{k}'] = this_F
        print(f'*** {ident_nick} --- {k} ***')
        print(1/np.sqrt(np.diag(this_F)))
        print(np.sqrt(np.diag(np.linalg.inv(this_F))))

fisher_triangle(ax, F['glx_VIDE'], 'black', 'solid', 'galaxy voids, reference', isfresh=True)
fisher_triangle(ax, F['glx_infer_mean'], 'orange', 'solid', 'galaxy voids, graph flow, mean', isfresh=False)
fisher_triangle(ax, F['glx_infer_samples'], 'orange', 'dashed', 'galaxy voids, graph flow, samples', isfresh=False)
# fisher_triangle(ax, F['dm_VIDE'], 'grey', 'solid', isfresh=False)
fisher_triangle(ax, F['dm_infer_mean'], 'green', 'solid', 'DM voids, graph flow, mean', isfresh=False, change_lims=False)
# fisher_triangle(ax, F['dm_infer_samples'], 'blue', 'dashed', isfresh=False)

# add legend
# for ii in range(5) :
#     for jj in range(5) :
#         print(f'{ii}, {jj}, {axs[ii,jj].get_legend_handles_labels()[1]}')
handles, labels = ax[1, 0].get_legend_handles_labels()
print(labels)
ax[1, 0].legend(handles, labels, bbox_to_anchor=(1.4, 1), borderaxespad=0)


fig.savefig(f'./figs/fisher_{NSTEPS}steps_b{LINK_LENGTH["glx"]}_corr{HAVE_CORR}.pdf', bbox_inches='tight')
