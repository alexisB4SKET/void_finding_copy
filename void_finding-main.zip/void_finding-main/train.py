from sys import stderr
import os
import os.path
import socket
import hashlib
from contextlib import nullcontext
import datetime
import time
import yaml

import numpy as np
from matplotlib import pyplot as plt

import torch
from torch.utils.tensorboard import SummaryWriter
from torch_geometric.loader import DataLoader as pyg_Dataloader
from torch_geometric.utils import scatter

from gnn import GNN
from dataset import DataSet
from cli import CLI
from load import load_model



def FakeTarget (data) :
    # do a super stupid thing and just take the mean of the last feature
    # have verified that this is doing what it's supposed to be doing
    # trains fine, but seemingly *only* with LayerNorm in MLPs!! (lr=1e-3)
    # With lr=1e-3, should reach better than 1e-6 after 1 epoch
    # NOTE reduce='max' works too, with an expressive network
    return scatter(data['G'].node_attr[:, -1][data['G', 'GP', 'P'].edge_index[0, :]],
                   data['G', 'GP', 'P'].edge_index[1, :],
                   reduce='mean', dim_size=len(data['P'].node_attr))

    # alternatively, for debugging, try taking mean of edge attribute -- init loss: ~0.5
    # trains fine, but seemingly *only* with LayerNorm in MLPs!! (lr=1e-3)
    # return scatter(data['G', 'GP', 'P'].edge_attr[:, -1],
    #      data['G', 'GP', 'P'].edge_index[1, :],
    #                reduce='mean', dim_size=len(data['P'].node_attr)).unsqueeze(-1)

    # something pretty dumb but not sooo trivial
    # It trains well with the full model, regardless of LayerNorm!
    # return data['P'].node_attr[:, -1].unsqueeze(-1)

    # this one trains
    #return torch.zeros((len(data['P'].node_attr), 1), device=data['P'].node_attr.device)


if __name__ == '__main__' :

    cli_args, cfg = CLI()

    if socket.gethostname() == 'igpu' : # we are on head node
        is_test_run = True
        world_size = 1
        rank = 0
        localid = 0
        device = f'cuda:{cli_args.device}'
    else :
        is_test_run = False
        world_size = int(os.environ['SLURM_NTASKS'])
        rank = int(os.environ['SLURM_PROCID'])
        localid = int(os.environ['SLURM_LOCALID'])
        device = f'cuda:{localid}'

    print(f'world_size={world_size}, rank={rank}, localid={localid}')

    if world_size > 1 :
        # the "default" group for CUDA collective
        torch.distributed.init_process_group(backend='nccl', world_size=world_size, rank=rank)

        # need another group to share small CPU things
        cpu_group = torch.distributed.new_group(backend='gloo')

    # get some identifiers, initialize the tensorboard instance
    if not rank :
        ident_fname = os.path.splitext(os.path.basename(cli_args.config))[0]
        ident_hashes = '-'.join([k[0].upper()+hashlib.md5(f'{v}'.encode()).hexdigest()[:4] for k, v in cfg.items()])
        timestamp = datetime.datetime.now().strftime("%m%d%H%M")
        ident = f'{ident_fname}_{ident_hashes}_{timestamp}'
        if is_test_run :
            ident = f'TEST_{ident}'
        writer = SummaryWriter(log_dir=f'/home/lthiele/gpfs/void_finding/train_logs/{ident}')
        writer.add_text('CONFIG', f'{cfg}')

        # for checkpointing
        outdir = f'/home/lthiele/gpfs/void_finding/checkpoints/{ident}'
        os.makedirs(outdir, exist_ok=True)
        with open(f'{outdir}/cfg.yaml', 'w') as fp :
            yaml.safe_dump(cfg, fp, sort_keys=False)

    # data set specification
    ds_kwargs = dict(
        **cfg['data'],
        **cfg['graph'],
        interpolant=cfg['training']['interpolant']
    )
    ds_kwargs['norm_hash'] = hashlib.md5(f'{ds_kwargs}'.encode()).hexdigest()[:4]

    trainset = DataSet(rank, 'train', **ds_kwargs)
    trainsampler = torch.utils.data.distributed.DistributedSampler(trainset, drop_last=True) if world_size>1 else None
    trainloader = pyg_Dataloader(trainset, batch_size=1,
                                 num_workers=cli_args.workers,
                                 sampler=trainsampler,
                                 shuffle=(trainsampler is None),
                                 persistent_workers=True,
                                 prefetch_factor=4,
                                 pin_memory=True)

    validset = DataSet(rank, 'valid', **ds_kwargs)
    validsampler = torch.utils.data.distributed.DistributedSampler(validset, drop_last=True) if world_size>1 else None
    validloader = pyg_Dataloader(validset, batch_size=1, num_workers=cli_args.workers,
                                 sampler=validsampler,
                                 shuffle=False,
                                 persistent_workers=True,
                                 prefetch_factor=4,
                                 pin_memory=True)

    # construct the network
    model = GNN(
        d_in_P=3*2*cfg['graph']['Nfourier']
               +3*len(cfg['graph']['kfeat'])*cfg['graph']['Nfeat']
               +cfg['data']['predict_R'],
        d_in_G=3*2*cfg['graph']['Nfourier']
               +3*len(cfg['graph']['kfeat'])*cfg['graph']['Nfeat'],
        d_edge=4, # TODO any feature engineering here?
        d_g=1,
        d_out=3+cfg['data']['predict_R'],
        **cfg['model']
    ).to(device)
    if not rank :
        print(f'Have {sum(v.numel() for _, v in model.named_parameters())*1e-6:.6f}M parameters')

    # compiling gives around 17% reduction in execution time for configuration B
    # might be more significant for deeper models
    # NOTE that this has to come *before* DDP
    # NOTE we only compile for actual compute runs (for quicker debugging)
    if not is_test_run :
        model = torch.compile(model, dynamic=True, fullgraph=True)

    if world_size > 1 :
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[device, ])

    # by hand accumulation
    micro_batch_size, rem = divmod(cfg['training']['batch_size'], world_size)
    assert not rem
    is_micro_batch_full = lambda t: (t % micro_batch_size)==(micro_batch_size-1)

    optimizer = torch.optim.Adam(model.parameters(), lr=cfg['training']['lr'])

    # load previous checkpoint from disk if requested
    if 'checkpoint' in cfg['training'] and cfg['training']['checkpoint'] is not None :
        model, optimizer = load_model(
            f'/home/lthiele/gpfs/void_finding/checkpoints/{cfg["training"]["checkpoint"]}',
            device=device, model=model, do_optim=True, optim=optimizer, ddp=True
        )

    # NOTE due to the accumulation, we can wrap around epochs
    # TODO add decaying scheduler for final training
    if 'scheduler' in cfg['training'] :
        lr_scheduler_num_steps = (len(trainloader) * cfg['training']['epochs']) // micro_batch_size
        lr_scheduler = torch.optim.lr_scheduler.OneCycleLR(
            optimizer, max_lr=cfg['training']['lr'],
            total_steps=lr_scheduler_num_steps,
            **cfg['training']['scheduler']
        )
    else :
        lr_scheduler = None

    if not rank :
        print(f'Will perform approximately {(len(trainloader))//micro_batch_size} steps per epoch')

    microstep = 0 # counts at the level of the accumulation
    global_step = 0 # counts once per accumulation, for reporting
    ltrain = torch.empty((micro_batch_size, ))
    ltrain_all = torch.empty((world_size*len(ltrain), ))
    lvalid = torch.empty((len(validloader), ))
    lvalid_all = torch.empty((world_size*len(lvalid), ))
    best_lvalid = 1e300

    # for interpolant diagnostics
    ttrain = torch.empty((micro_batch_size, ))
    ttrain_all = torch.empty((world_size*len(ttrain), ))

    for epoch in range(cfg['training']['epochs']) :

        model.train()

        if world_size>1 :
            # required for shuffling to work correctly
            trainsampler.set_epoch(epoch)

        if not rank :
            ltrain_allepoch = np.empty(0)
            ttrain_allepoch = np.empty(0)

        for step, x in enumerate(trainloader) :

            x = x.to(device)

            # we don't want to sync on backward() every single step
            with model.no_sync() if world_size>1 and not is_micro_batch_full(microstep) else nullcontext() :
                y = model(x)
                ytarg = x['P'].node_targ
                l = (ytarg - y).square().mean()

                # NOTE that we need to correctly normalize by the number of accumulation steps!
                (l/micro_batch_size).backward()

            ltrain[microstep % micro_batch_size] = l.item()
            ttrain[microstep % micro_batch_size] = x['U'].g.item()

            if is_micro_batch_full(microstep) :

                # gather all training losses
                if world_size>1 :
                    torch.distributed.all_gather_into_tensor(ltrain_all, ltrain, group=cpu_group)
                    torch.distributed.all_gather_into_tensor(ttrain_all, ttrain, group=cpu_group)
                else :
                    ltrain_all = ltrain
                    ttrain_all = ttrain

                # record what's going on
                if not rank :
                    ltrain_allepoch = np.concat([ltrain_allepoch, ltrain_all.numpy(force=True)])
                    ttrain_allepoch = np.concat([ttrain_allepoch, ttrain_all.numpy(force=True)])
                    writer.add_scalar('Loss/train', ltrain_all.mean(), global_step)
                    if lr_scheduler is not None :
                        writer.add_scalar('lr', lr_scheduler.get_last_lr()[0], global_step)

                global_step += 1
                assert global_step*micro_batch_size == microstep+1

                # now we perform the computations
                optimizer.step()
                optimizer.zero_grad()
                if lr_scheduler is not None :
                    try : # it's better to be a bit flexible here
                        lr_scheduler.step()
                    except ValueError :
                        pass

            microstep += 1

        # finished eopoch
        if not rank :
            fig, ax = plt.subplots(figsize=(10, 10))
            ax.hist2d(
                ttrain_allepoch, ltrain_allepoch,
                bins=[
                    np.linspace(0, 1, 65),
                    np.linspace(np.quantile(ltrain_allepoch, 0.01), np.quantile(ltrain_allepoch, 0.99), 65),
                ]
            )
            ax.set_xlabel('time')
            ax.set_ylabel('loss')
            ax.set_title(f'Epoch = {epoch}')
            writer.add_figure('Diagnostic/LossHist', fig, global_step)

        model.eval()

        with torch.no_grad() :
            for step, x in enumerate(validloader) :

                x = x.to(device)
                y = model(x) # no global context so far
                ytarg = x['P'].node_targ
                l = (ytarg - y).square().mean()

                lvalid[step] = l.item()

            # gather all validation losses
            if world_size>1 :
                torch.distributed.all_gather_into_tensor(lvalid_all, lvalid, group=cpu_group)
            else :
                lvalid_all = lvalid

            if not rank :
                this_lvalid = lvalid_all.mean().item()
                writer.add_scalar('Loss/valid', this_lvalid, global_step)

                # save to file if it's the best model
                # TODO for the final push, in view of potential overfitting, let's always save (in separate file)
                if this_lvalid < best_lvalid :
                    best_lvalid = this_lvalid
                    torch.save(model.state_dict(), f'{outdir}/model.pt')
                    torch.save(optimizer.state_dict(), f'{outdir}/optimizer.pt')
