# driver script for a single simulation

set -euo pipefail

idx="$1"

version='part'

cfg="vide_cfg_${version}.py"

# TODO put data on GPFS later
wrkdir="/home/lthiele/void_finding/Quijote_fidHR/${idx}/"

mkdir -p "$wrkdir"

bash prepare_catalog.sh \
  "/home/lthiele/cd3globus/Quijote_fidHR/rockstar/${idx}/out_4_pid.list" \
  "${wrkdir}/out_4_pid.list.multidark"

cp "$cfg" "$wrkdir"
cd "$wrkdir"
vide_prepare_simulation --all --parm "$cfg"

if [ "$version" == 'part' ]; then
  script="${version}based_ss1.0.py"
else
  script="${version}based_hod_TestHOD_LFT.py"
fi

python -m void_pipeline "./scripts/${script}"
