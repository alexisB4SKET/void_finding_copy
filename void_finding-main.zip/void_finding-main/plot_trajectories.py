from sys import argv

import numpy as np
from matplotlib import pyplot as plt
import torch

from load import load_model, load_dset
from fof import FoF


def get_trajectories (model, dset, idx, N, seed=None) :
    device = next(model.parameters()).device

    seed = 137 if seed is None else seed

    rng = torch.Generator().manual_seed(seed)
    xG, xP, xT, RP, RT = dset.get_particles(idx, rng, do_augments=False)

    traj = torch.empty((N+1, dset.NP, 3))
    traj[0] = xP.to(traj.device)

    # our choice of times: the paths tend to be more curved at the beginning,
    # so we devote more precision there,
    # and then we add a bit of precision at the end so we get good convergence of paths
    t_ = np.linspace(0,1,num=Nsteps+1)
    tarr = (1-0.1)*(3*t_**2-2*t_**3)**1.5+0.1*t_
    harr = tarr[1:]-tarr[:-1]
    tarr = tarr[:-1]

    model.eval()
    with torch.no_grad() :
        for ii in range(N) :
            t = tarr[ii]
            h = harr[ii]
            x = dset.assemble_output(xG, xP, None, RP, None, t).to(device)
            v = model(x)
            xP += 100.0 * v[:, :3].to(xP.device) * h
            RP += v[:, 3:4].to(RP.device) * h
            traj[ii+1] = xP.to(traj.device)
            print(f'Done {ii+1} / {N}')

    return (
        xG.numpy(force=True),
        xT.numpy(force=True),
        traj.numpy(force=True).transpose(1, 0, 2),
        RT.numpy(force=True).squeeze(),
        RP.numpy(force=True).squeeze(),
    )

if __name__ == '__main__' :

    ident = argv[1]
    device = f'cuda:{int(argv[2])}'
    Nsteps = int(argv[3])
    seed = int(argv[4]) if len(argv)==5 else None
    idx = 0
    mode = 'testfid'

    base = f'/home/lthiele/gpfs/void_finding/checkpoints/{ident}'
    
    model, _ = load_model(base, device=device, ddp=False, compiled=False)
    dset = load_dset(base, mode)

    xG, xT, traj, RT, RP = get_trajectories(model, dset, idx, Nsteps, seed)

    # find the FoF groups
    group_ids = FoF(traj[:, -1, :], 15.0)

    # get back into normal units
    RT = dset.Rmin * np.exp(RT)
    RP = dset.Rmin * np.exp(RP)

    delta_z = 50.0
    pmask = np.fabs(xT[:, 2] - 500.0) < delta_z
    gmask = np.fabs(xG[:, 2] - 500.0) < delta_z
    tmask = np.fabs(traj[:, -1, 2] - 500.0) < delta_z

    fig, ax = plt.subplots(figsize=(5, 5))
    ax.plot(xT[pmask, 0], xT[pmask, 1], linestyle='none', marker='x', color='black', label='target voids')
    ax.plot(xG[gmask, 0], xG[gmask, 1], linestyle='none', marker='o', markersize=0.2, color='grey', label='galaxies')
    # for ii in np.where(pmask)[0] :
    #     ax.text(xT[ii, 0], xT[ii, 1], f'{RT[ii]:.1f}', color='orange', va='bottom', ha='left')

    c = 'orange' if 'glx' in ident else 'green'

    for ii in np.where(tmask)[0] :
        ax.plot(traj[ii][:, 0], traj[ii][:, 1], linestyle='solid', color=c, label='test particle trajectories' if ii==np.where(tmask)[0][0] else None)
        # ax.text(traj[ii][-1, 0], traj[ii][-1, 1], f'{group_ids[ii]}-{RP[ii]:.1f}', color='black', va='top', ha='right', fontsize='xx-small')
        ax.plot([traj[ii][0, 0], ], [traj[ii][0, 1], ], linestyle='none', marker='o', color=c, markersize=5)

        # this doesn't work right now
        # ax.plot([traj[ii][-1, 0], xT[ii, 0]], [traj[ii][-1, 1], xT[ii, 1]],
        #         linestyle='dashed', color='grey')

    ax.set_xlim(0, 1e3)
    ax.set_ylim(0, 1e3)

    if seed is None :
        ax.set_xlabel('$X$ [Mpc/$h$]')
        ax.set_ylabel('$Y$ [Mpc/$h$]')
        ax.legend(bbox_to_anchor=(0, 1.02), borderaxespad=0, loc='lower left', ncol=2)
    else :
        ax.set_xticks([])
        ax.set_yticks([])

    seed_prt = '' if seed is None else f'_{seed}'

    fig.savefig(f'./figs/trajectories_{ident}_{mode}{idx}{seed_prt}.pdf', bbox_inches='tight')
