#!/usr/bin/env bash
set -eo pipefail
source ~/.bashrc

starttime=$(date +%s)

DB_HOST='idark'
DB_PORT='3310'
DB_USER='myusr'
DB_PASS='mypwd'
DB_NAME='void_finding'

MYSQL_OPTS="-h${DB_HOST} -P${DB_PORT} -u${DB_USER} -p${DB_PASS} --batch --silent --skip-column-names ${DB_NAME}"

micromamba activate mysql

# get the next index
SQL=$(cat <<SQL
START TRANSACTION;

SELECT s.idx
INTO @next
FROM vide_state_dm s
WHERE s.state='none'
ORDER BY s.idx ASC
LIMIT 1
FOR UPDATE;

UPDATE vide_state_dm
SET state='rsv'
WHERE idx=@next;

COMMIT;

SELECT @next;
SQL
)
this_idx=$(mysql ${MYSQL_OPTS} -e "${SQL}")

# deal with case of no work left
if [ -z $this_idx ]; then
  exit 1
fi


# run vide
mysql ${MYSQL_OPTS} -e "UPDATE vide_state_dm SET state='running' WHERE idx=${this_idx};"
bash run_vide_dm.sh "$this_idx"

if [[ $? -ne 0 ]]; then
  state='failure'
else
  state='success'
fi

mysql ${MYSQL_OPTS} -e "UPDATE vide_state_dm SET state='${state}' WHERE idx=${this_idx};"

micromamba deactivate

endtime=$(date +%s)
deltat=$(( endtime - starttime ))
deltat_hr=$(( deltat / 3600 ))
deltat_mn=$(( (deltat % 3600) / 60 ))
deltat_sc=$(( deltat % 60 ))
echo "Took ${deltat_hr}:${deltat_mn}:${deltat_sc} for idx=${this_idx}"
