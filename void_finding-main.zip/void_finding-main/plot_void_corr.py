import numpy as np
from matplotlib import pyplot as plt

rmin_g = [0, 20, 40, ]
rmin_p = [0, 10, 20, ]

totl = len(rmin_g) * len(rmin_p)

fp = np.load('void_corr.npz')
s = fp['s']

fig, ax = plt.subplots(figsize=(10, 10))

ls = ['-', '--', '-.', ]
ms = ['o', 'v', '^', ]
for ii, rmin_p_ in enumerate(rmin_p) :
    for jj, rmin_g_ in enumerate(rmin_g) :
        xiavg = np.mean(fp[f'xi_gvoids_R{rmin_g_}_pvoids_R{rmin_p_}'], 0)
        xistd = np.std(fp[f'xi_gvoids_R{rmin_g_}_pvoids_R{rmin_p_}'], 0)
        # do some jittering for better visibility
        idx = ii*len(rmin_g)+jj
        pos = (idx - 0.5*totl)/totl
        ax.plot(s+pos*(s[1]-s[0])*0.5, xiavg,
                label=f'g{rmin_g_}_p{rmin_p_}', linestyle=ls[ii], marker=ms[jj])

ax.set_xlabel('s [Mpc/h]')
ax.set_ylabel('galaxy voids x particle voids')
ax.axhline(0, color='grey')
#ax.set_xlim(0, 30)
ax.legend()

fig.savefig('void_corr.png', dpi=300, bbox_inches='tight')
