import numpy as np
from scipy.spatial import KDTree

def FoF(x, b):

    N, dim = x.shape

    tree = KDTree(x)

    # Find all unordered pairs (i, j) with |x_i - x_j| < linking_length
    pairs = tree.query_pairs(r=b)

    # Union-Find (Disjoint Set) to build connected components
    parent = np.arange(N, dtype=int)
    rank = np.zeros(N, dtype=int)

    def find(i):
        # Path compression
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(i, j):
        ri, rj = find(i), find(j)
        if ri == rj:
            return
        # Union by rank
        if rank[ri] < rank[rj]:
            parent[ri] = rj
        elif rank[ri] > rank[rj]:
            parent[rj] = ri
        else:
            parent[rj] = ri
            rank[ri] += 1

    for i, j in pairs:
        union(i, j)

    # Compress all roots
    roots = np.fromiter((find(i) for i in range(N)), dtype=int, count=N)

    # Map each unique root to a consecutive group ID
    unique_roots, group_ids = np.unique(roots, return_inverse=True)
    return group_ids
