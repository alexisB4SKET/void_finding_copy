world_size=4

#for ident in 'fnlglxB_D876b-G58f0-M8b51-Tc7ea_12042051' 'fnldmA_Dc106-G58f0-M8b51-T63f1_11292333'; do
for ident in 'fnldmA_Dc106-G58f0-M8b51-T63f1_11292333'; do
  for version in 'fid' 'bsq'; do
    for rank in $( seq 0 $((world_size-1)) ); do
      python vsf.py "$ident" "$version" $rank $world_size &
    done
  done
done

wait
