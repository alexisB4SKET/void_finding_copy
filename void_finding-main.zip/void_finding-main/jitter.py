from sys import argv

import numpy as np

fin = argv[1]
fout = argv[2]
seed = int(argv[3])
std = float(argv[4])

BOXSIZE = 1e3

def jitter (x) :
    rng = np.random.default_rng(seed)
    return np.mod(rng.normal(loc=x, scale=std), BOXSIZE)

with open(fin, 'rb') as fpin, open(fout, 'wb') as fpout :

    # copy the header
    np.fromfile(fpin, dtype=np.int32, count=1).tofile(fpout)
    np.fromfile(fpin, dtype=np.byte, count=256).tofile(fpout)
    np.fromfile(fpin, dtype=np.int32, count=1).tofile(fpout)

    # coordinates
    nbytes = np.fromfile(fpin, dtype=np.int32, count=1)
    N = nbytes.item() // (3*4)
    nbytes.tofile(fpout)
    jitter(np.fromfile(fpin, dtype=np.float32, count=N*3)).astype(np.float32).tofile(fpout)
    np.fromfile(fpin, dtype=np.int32, count=1).tofile(fpout)

    # velocities
    np.fromfile(fpin, dtype=np.int32, count=1).tofile(fpout)
    np.fromfile(fpin, dtype=np.float32, count=N*3).tofile(fpout)
    np.fromfile(fpin, dtype=np.int32, count=1).tofile(fpout)

    # particleIDs
    np.fromfile(fpin, dtype=np.int32, count=1).tofile(fpout)
    np.fromfile(fpin, dtype=np.int32, count=N).tofile(fpout)
    np.fromfile(fpin, dtype=np.int32, count=1).tofile(fpout)

    assert not fpin.read()
