# A quick script to transform the Rockstar output files into VIDE-friendly files

fin="$1"
fout="$2"

N=$(wc -l < "$fin")
N=$(( N - 16 ))

echo 1000.00000 > "$fout"
echo 0.317500 >> "$fout"
echo 0.671100 >> "$fout"
echo 0.0 >> "$fout"
echo "$N" >> "$fout"
tail -n +17 "$fin" | awk '{print $1, $9, $10, $11, $12, $13, $14, $3 }' >> "$fout"
echo '-99 -99 -99 -99 -99 -99 -99 -99' >> "$fout"
